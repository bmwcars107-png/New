package io.noctis.hud;

import io.noctis.gui.Render2D;
import io.noctis.gui.Theme;
import io.noctis.module.Category;
import io.noctis.module.Module;
import io.noctis.module.ModuleManager;
import io.noctis.NoctisClient;
import io.noctis.setting.BoolSetting;
import io.noctis.setting.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/** All HUD elements. Each is an independent module with its own position, scale, opacity and colours. */
public final class HudElements {
    private HudElements() {}

    private static final MinecraftClient MC = MinecraftClient.getInstance();

    static void panel(HudModule m, DrawContext c, float a) {
        if (!m.background.on()) return;
        Render2D.rrect(c, 0, 0, m.w(), m.h(), 3, Render2D.a(0xE00B0B11, a));
        Render2D.rrect(c, 0, 2, 2, m.h() - 4, 1, Render2D.a(m.color.rgb(), a));
    }

    private static int text(HudModule m, float a) { return Render2D.a(Theme.TEXT, a); }
    private static int dim(float a) { return Render2D.a(Theme.DIM, a); }

    public static List<HudModule> create() {
        return List.of(new Watermark(), new Fps(), new Coordinates(), new Keystrokes(), new Armor(),
                new Effects(), new Ping(), new ModuleList(), new TargetInfo());
    }

    // ------------------------------------------------------------------------------------------
    public static final class Watermark extends HudModule {
        public Watermark() { super("Watermark", "Client name tag with a gradient wordmark.", 6, 6, 0x8B5CF6); defaultEnabled = true; }
        @Override public int w() { return Render2D.tw("NOCTIS  " + NoctisClient.VERSION) + 12; }
        @Override public int h() { return 16; }
        @Override public void draw(DrawContext c, float a) {
            panel(this, c, a);
            int x = 7;
            String word = "NOCTIS";
            for (int i = 0; i < word.length(); i++) {
                String ch = String.valueOf(word.charAt(i));
                Render2D.text(c, ch, x, 4, Render2D.a(Render2D.mix(Theme.primary(), Theme.secondary(), i / 5f), a));
                x += Render2D.tw(ch);
            }
            Render2D.text(c, "  " + NoctisClient.VERSION, x, 4, dim(a));
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class Fps extends HudModule {
        public Fps() { super("FPS", "Frames per second and average frame time (derived from FPS).", 6, 26, 0x8B5CF6); defaultEnabled = true; }
        private String line() { int f = MC.getCurrentFps(); return "FPS " + f + "   " + String.format("%.1f", f > 0 ? 1000f / f : 0f) + " ms"; }
        @Override public int w() { return Render2D.tw(line()) + 12; }
        @Override public int h() { return 16; }
        @Override public void draw(DrawContext c, float a) {
            panel(this, c, a);
            Render2D.text(c, line(), 7, 4, text(this, a));
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class Coordinates extends HudModule {
        private final BoolSetting decimals = add(new BoolSetting("Decimals", "Show one decimal place", false));
        public Coordinates() { super("Coordinates", "Position and facing direction.", 6, 66, 0x8B5CF6); defaultEnabled = true; }
        private String l1() {
            if (MC.player == null) return "XYZ 0 64 0";
            return decimals.on() ? String.format("XYZ %.1f %.1f %.1f", MC.player.getX(), MC.player.getY(), MC.player.getZ())
                    : String.format("XYZ %d %d %d", (int) Math.floor(MC.player.getX()), (int) Math.floor(MC.player.getY()), (int) Math.floor(MC.player.getZ()));
        }
        private String l2() {
            if (MC.player == null) return "Facing north";
            String f = MC.player.getHorizontalFacing().asString();
            return "Facing " + f + String.format("  (%.0f)", net.minecraft.util.math.MathHelper.wrapDegrees(MC.player.getYaw()));
        }
        @Override public int w() { return Math.max(Render2D.tw(l1()), Render2D.tw(l2())) + 12; }
        @Override public int h() { return 28; }
        @Override public void draw(DrawContext c, float a) {
            panel(this, c, a);
            Render2D.text(c, l1(), 7, 4, text(this, a));
            Render2D.text(c, l2(), 7, 16, dim(a));
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class Keystrokes extends HudModule {
        private final BoolSetting mouse = add(new BoolSetting("Mouse buttons", "Show LMB / RMB", true));
        private final BoolSetting space = add(new BoolSetting("Space bar", "Show the jump key", true));
        public Keystrokes() { super("Keystrokes", "Movement keys and mouse buttons.", 6, 102, 0xE11D48); }
        @Override public int w() { return 3 * 22 + 4; }
        @Override public int h() { return 22 + 2 + 22 + (mouse.on() ? 24 : 0) + (space.on() ? 14 : 0); }
        private void key(DrawContext c, int x, int y, int w, int h, String label, boolean down, float a) {
            Render2D.rrect(c, x, y, w, h, 3, Render2D.a(down ? Render2D.mix(0xFF181823, Theme.primary(), 0.75f) : 0xE00B0B11, a));
            Render2D.centered(c, label, x + w / 2, y + (h - 8) / 2, Render2D.a(down ? 0xFFFFFFFF : Theme.DIM, a));
        }
        @Override public void draw(DrawContext c, float a) {
            var o = MC.options;
            key(c, 24, 0, 22, 22, "W", o.forwardKey.isPressed(), a);
            key(c, 0, 24, 22, 22, "A", o.leftKey.isPressed(), a);
            key(c, 24, 24, 22, 22, "S", o.backKey.isPressed(), a);
            key(c, 48, 24, 22, 22, "D", o.rightKey.isPressed(), a);
            int y = 48;
            if (mouse.on()) {
                long win = MC.getWindow().getHandle();
                key(c, 0, y, 34, 22, "LMB", GLFW.glfwGetMouseButton(win, 0) == GLFW.GLFW_PRESS, a);
                key(c, 36, y, 34, 22, "RMB", GLFW.glfwGetMouseButton(win, 1) == GLFW.GLFW_PRESS, a);
                y += 24;
            }
            if (space.on()) key(c, 0, y, 70, 12, "SPACE", o.jumpKey.isPressed(), a);
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class Armor extends HudModule {
        private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        private final BoolSetting percent = add(new BoolSetting("Durability %", "Show remaining durability as a percentage", true));
        public Armor() { super("ArmorHud", "Worn armor with remaining durability.", 6, 194, 0xC4C9D4); }
        @Override public int w() { return percent.on() ? 58 : 26; }
        @Override public int h() { return 4 * 18 + 4; }
        @Override public void draw(DrawContext c, float a) {
            panel(this, c, a);
            for (int i = 0; i < 4; i++) {
                ItemStack s = MC.player == null ? ItemStack.EMPTY : MC.player.getEquippedStack(SLOTS[i]);
                int y = 3 + i * 18;
                if (s.isEmpty()) {
                    Render2D.rrect(c, 5, y, 16, 16, 2, Render2D.a(0x40FFFFFF, a));
                    continue;
                }
                c.drawItem(s, 5, y);
                if (percent.on() && s.getMaxDamage() > 0) {
                    int pct = (s.getMaxDamage() - s.getDamage()) * 100 / s.getMaxDamage();
                    int col = pct > 50 ? 0xFF7DDC8E : pct > 20 ? 0xFFE8C45A : Theme.WARN;
                    Render2D.text(c, pct + "%", 25, y + 4, Render2D.a(col, a));
                } else if (percent.on()) Render2D.text(c, "--", 25, y + 4, dim(a));
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class Effects extends HudModule {
        public Effects() { super("Effects", "Active potion effects with remaining time.", 6, 278, 0x8B5CF6); }
        private List<String> lines() {
            List<String> out = new ArrayList<>();
            if (MC.player != null) {
                Module fb = ModuleManager.get("Fullbright");
                boolean hideNv = fb != null && fb.isEnabled();
                for (StatusEffectInstance e : MC.player.getStatusEffects()) {
                    if (hideNv && e.getEffectType().equals(net.minecraft.entity.effect.StatusEffects.NIGHT_VISION)) continue; // Fullbright's own client-side effect
                    int sec = e.isInfinite() ? -1 : e.getDuration() / 20;
                    String t = sec < 0 ? "inf" : String.format("%d:%02d", sec / 60, sec % 60);
                    out.add(e.getEffectType().value().getName().getString() + (e.getAmplifier() > 0 ? " " + (e.getAmplifier() + 1) : "") + "  " + t);
                }
            }
            if (out.isEmpty() && HudManager.preview) out.add("Speed 2  0:42");
            return out;
        }
        @Override public int w() { int m = 60; for (String s : lines()) m = Math.max(m, Render2D.tw(s)); return m + 12; }
        @Override public int h() { return Math.max(1, lines().size()) * 11 + 6; }
        @Override public void draw(DrawContext c, float a) {
            List<String> l = lines();
            if (l.isEmpty()) return;
            panel(this, c, a);
            for (int i = 0; i < l.size(); i++) Render2D.text(c, l.get(i), 7, 4 + i * 11, text(this, a));
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class Ping extends HudModule {
        public Ping() { super("Ping", "Latency from the server's player list (not available in singleplayer).", 6, 46, 0x8B5CF6); }
        private String line() {
            if (MC.player == null || MC.getNetworkHandler() == null) return "Ping --";
            if (MC.isInSingleplayer()) return "Ping local";
            PlayerListEntry e = MC.getNetworkHandler().getPlayerListEntry(MC.player.getUuid());
            return e == null ? "Ping --" : "Ping " + e.getLatency() + " ms";
        }
        @Override public int w() { return Render2D.tw(line()) + 12; }
        @Override public int h() { return 16; }
        @Override public void draw(DrawContext c, float a) { panel(this, c, a); Render2D.text(c, line(), 7, 4, text(this, a)); }
    }

    // ------------------------------------------------------------------------------------------
    public static final class ModuleList extends HudModule {
        private final ModeSetting order = add(new ModeSetting("Order", "Sort order", "Longest first", "Longest first", "Alphabetical"));
        private final BoolSetting showHud = add(new BoolSetting("Include HUD", "Also list HUD elements", false));
        private List<String> cache = List.of();
        private long cacheAt;
        public ModuleList() { super("ModuleList", "Toggleable list of enabled modules.", 330, 6, 0xE11D48); defaultEnabled = true; }
        private List<String> names() {
            long now = System.currentTimeMillis();
            if (now - cacheAt < 250 && !HudManager.preview) return cache; // avoid rebuilding every frame
            cacheAt = now;
            List<String> l = new ArrayList<>();
            for (Module m : ModuleManager.all())
                if (m.isEnabled() && !m.action && (showHud.on() || m.category != Category.HUD)) l.add(m.name);
            if (l.isEmpty() && HudManager.preview) l.add("Sprint");
            if (order.is("Alphabetical")) Collections.sort(l);
            else l.sort(Comparator.comparingInt(Render2D::tw).reversed());
            return cache = l;
        }
        @Override public int w() { int m = 40; for (String s : names()) m = Math.max(m, Render2D.tw(s)); return m + 12; }
        @Override public int h() { return Math.max(1, names().size()) * 11 + 6; }
        @Override public void draw(DrawContext c, float a) {
            List<String> l = names();
            if (l.isEmpty()) return;
            panel(this, c, a);
            for (int i = 0; i < l.size(); i++) {
                int col = Render2D.mix(Theme.primary(), Theme.secondary(), l.size() <= 1 ? 0 : i / (float) (l.size() - 1));
                Render2D.text(c, l.get(i), 7, 4 + i * 11, Render2D.a(col, a));
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class TargetInfo extends HudModule {
        public TargetInfo() { super("TargetInfo", "Name and health of the living entity under your crosshair (already visible information only).", 200, 6, 0xE11D48); }
        private LivingEntity target() { return MC.targetedEntity instanceof LivingEntity le ? le : null; }
        @Override public int w() { return 110; }
        @Override public int h() { return HudManager.preview || target() != null ? 28 : 0; }
        @Override public void draw(DrawContext c, float a) {
            LivingEntity t = target();
            if (t == null && !HudManager.preview) return;
            panel(this, c, a);
            String name = t == null ? "Sample Target" : t.getName().getString();
            float hp = t == null ? 14f : t.getHealth(), max = t == null ? 20f : Math.max(1f, t.getMaxHealth());
            Render2D.text(c, Render2D.trim(name, 98), 7, 4, text(this, a));
            Render2D.rrect(c, 7, 17, 96, 5, 2, Render2D.a(0xFF2A2A3A, a));
            int bar = Math.max(2, Math.round(96 * Math.min(1f, hp / max)));
            Render2D.rrect(c, 7, 17, bar, 5, 2, Render2D.a(Render2D.mix(Theme.secondary(), 0xFF7DDC8E, hp / max), a));
        }
    }
}
