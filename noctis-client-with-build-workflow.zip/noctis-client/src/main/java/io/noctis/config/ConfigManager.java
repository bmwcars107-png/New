package io.noctis.config;

import com.google.gson.*;
import io.noctis.NoctisClient;
import io.noctis.module.Module;
import io.noctis.module.ModuleManager;
import io.noctis.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Profiles live in config/noctis/profiles/NAME.json. Every load is validated value by value:
 * a bad value falls back to its default and is reported in {@link #warnings}; an unreadable file is
 * moved aside as NAME.corrupt-TIMESTAMP and replaced with defaults.
 */
public final class ConfigManager {
    public static final int SCHEMA = 1;
    public static final String DEFAULT_PROFILE = "default", PRIVATE_TEST_PROFILE = "private-test";
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_-]{1,32}");

    private static Path root, profiles;
    private static String active = DEFAULT_PROFILE;
    private static boolean dirty, loading;
    private static int ticks;
    public static final List<String> warnings = new ArrayList<>();
    public static String message = "";
    private static String pendingServer; // "server" value of a profile being imported, kept on its first write

    private ConfigManager() {}

    public static void init() {
        root = FabricLoader.getInstance().getConfigDir().resolve("noctis");
        profiles = root.resolve("profiles");
        try {
            Files.createDirectories(profiles);
            Path state = root.resolve("state.json");
            if (Files.exists(state)) {
                JsonObject o = JsonParser.parseString(Files.readString(state)).getAsJsonObject();
                if (o.has("active") && NAME.matcher(o.get("active").getAsString()).matches()) active = o.get("active").getAsString();
            }
        } catch (Exception e) {
            NoctisClient.LOG.warn("Could not read state.json, using default profile: {}", e.toString());
        }
        for (String p : new String[]{DEFAULT_PROFILE, PRIVATE_TEST_PROFILE}) {
            if (!Files.exists(file(p))) { applyDefaults(); write(p); }
        }
        load(active);
    }

    public static String active() { return active; }
    public static boolean isPrivateTest(String name) { return name.startsWith(PRIVATE_TEST_PROFILE); }
    public static void markDirty() { if (!loading) dirty = true; }

    public static void autosaveTick() {
        if (dirty && ++ticks >= 100) { ticks = 0; save(); }
    }

    private static Path file(String name) { return profiles.resolve(name + ".json"); }

    public static List<String> list() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(profiles)) {
            s.map(p -> p.getFileName().toString()).filter(n -> n.endsWith(".json"))
                    .map(n -> n.substring(0, n.length() - 5)).filter(n -> NAME.matcher(n).matches()).sorted().forEach(out::add);
        } catch (IOException ignored) { }
        return out;
    }

    // --- save ---------------------------------------------------------------------------------
    public static void save() { write(active); dirty = false; saveState(); }

    private static void saveState() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("active", active);
            Files.writeString(root.resolve("state.json"), GSON.toJson(o), StandardCharsets.UTF_8);
        } catch (IOException e) { NoctisClient.LOG.warn("state save failed: {}", e.toString()); }
    }

    private static void write(String name) {
        JsonObject o = new JsonObject();
        o.addProperty("schema", SCHEMA);
        o.addProperty("profile", name);
        o.addProperty("privateTest", isPrivateTest(name));
        String srv = pendingServer != null ? pendingServer : serverOf(name);
        if (srv != null) o.addProperty("server", srv);
        JsonObject mods = new JsonObject();
        for (Module m : ModuleManager.all()) {
            if (m.status == io.noctis.module.Status.PLANNED || m.status == io.noctis.module.Status.BLOCKED) continue;
            JsonObject mo = new JsonObject();
            if (m.persistsEnabled()) mo.addProperty("enabled", m.isEnabled());
            mo.addProperty("key", m.key());
            JsonObject so = new JsonObject();
            for (Setting<?> s : m.settings) so.add(s.name, s.toJson());
            mo.add("settings", so);
            mods.add(m.name, mo);
        }
        o.add("modules", mods);
        try {
            Path tmp = file(name).resolveSibling(name + ".tmp");
            Files.writeString(tmp, GSON.toJson(o), StandardCharsets.UTF_8);
            try { Files.move(tmp, file(name), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(tmp, file(name), StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException e) {
            NoctisClient.LOG.error("Could not save profile {}: {}", name, e.toString());
            message = "Save failed: " + e.getMessage();
        }
    }

    // --- load ---------------------------------------------------------------------------------
    public static boolean load(String name) {
        if (!NAME.matcher(name).matches()) { message = "Invalid profile name."; return false; }
        warnings.clear();
        Path f = file(name);
        if (!Files.exists(f)) { applyDefaults(); active = name; write(name); saveState(); message = "Created profile '" + name + "'."; return true; }
        try {
            JsonObject o = JsonParser.parseString(Files.readString(f, StandardCharsets.UTF_8)).getAsJsonObject();
            apply(o);
            active = name;
            saveState();
            message = warnings.isEmpty() ? "Loaded '" + name + "'." : "Loaded '" + name + "' with " + warnings.size() + " repaired value(s).";
            return true;
        } catch (Exception e) {
            try { Files.move(f, profiles.resolve(name + ".corrupt-" + System.currentTimeMillis()), StandardCopyOption.REPLACE_EXISTING); }
            catch (IOException ignored) { }
            applyDefaults();
            active = name;
            write(name);
            saveState();
            message = "'" + name + "' was unreadable (" + e.getClass().getSimpleName() + "); reset to defaults, original kept as .corrupt.";
            return false;
        }
    }

    private static void apply(JsonObject o) {
        if (!o.has("schema") || !o.get("schema").isJsonPrimitive() || o.get("schema").getAsInt() < 1 || o.get("schema").getAsInt() > SCHEMA)
            throw new IllegalArgumentException("unsupported schema");
        if (!o.has("modules") || !o.get("modules").isJsonObject()) throw new IllegalArgumentException("missing modules");
        loading = true;
        try {
            applyDefaults();
            JsonObject mods = o.getAsJsonObject("modules");
            List<Module> toEnable = new ArrayList<>();
            for (Module m : ModuleManager.all()) {
                if (!mods.has(m.name) || !mods.get(m.name).isJsonObject()) continue;
                JsonObject mo = mods.getAsJsonObject(m.name);
                if (mo.has("key")) {
                    try { int k = mo.get("key").getAsInt(); if (k == -1 || (k >= 32 && k <= 348)) m.setKey(k); else throw new IllegalArgumentException("range"); }
                    catch (RuntimeException e) { warnings.add(m.name + ".key invalid"); }
                }
                if (mo.has("settings") && mo.get("settings").isJsonObject()) {
                    JsonObject so = mo.getAsJsonObject("settings");
                    for (Setting<?> s : m.settings) {
                        if (!so.has(s.name)) continue;
                        try { s.fromJson(so.get(s.name)); }
                        catch (RuntimeException e) { s.reset(); warnings.add(m.name + "." + s.name + ": " + e.getMessage()); }
                    }
                }
                if (m.persistsEnabled() && mo.has("enabled")) {
                    try { if (mo.get("enabled").getAsBoolean()) toEnable.add(m); } catch (RuntimeException e) { warnings.add(m.name + ".enabled invalid"); }
                }
            }
            // Modules not mentioned keep their default enabled state.
            for (Module m : ModuleManager.all()) {
                boolean mentioned = mods.has(m.name) && mods.get(m.name).isJsonObject() && mods.getAsJsonObject(m.name).has("enabled");
                if (!mentioned && m.defaultEnabled && !toEnable.contains(m)) toEnable.add(m);
            }
            ModuleManager.disableAll();
            for (Module m : toEnable) if (!m.setEnabled(true)) warnings.add(m.name + " not enabled: " + m.notice);
        } finally { loading = false; }
        dirty = false;
    }

    /** Reset all modules/settings to factory defaults (does not touch other profiles). */
    public static void applyDefaults() {
        boolean was = loading;
        loading = true;
        try {
            ModuleManager.disableAll();
            for (Module m : ModuleManager.all()) m.resetToDefaults();
            for (Module m : ModuleManager.all()) if (m.defaultEnabled) m.setEnabled(true);
        } finally { loading = was; }
        dirty = true;
    }

    // --- profile management ---------------------------------------------------------------------
    public static boolean create(String name) {
        if (!NAME.matcher(name).matches()) { message = "Names: letters, digits, _ and - (max 32)."; return false; }
        if (Files.exists(file(name))) { message = "Profile '" + name + "' already exists."; return false; }
        save();
        write(name); // copy of current state
        message = "Created '" + name + "' from the current settings.";
        return true;
    }

    public static boolean delete(String name) {
        if (name.equals(DEFAULT_PROFILE) || name.equals(PRIVATE_TEST_PROFILE)) { message = "Built-in profiles cannot be deleted."; return false; }
        try { Files.deleteIfExists(file(name)); } catch (IOException e) { message = "Delete failed."; return false; }
        if (name.equals(active)) load(DEFAULT_PROFILE);
        message = "Deleted '" + name + "'.";
        return true;
    }

    public static void switchTo(String name) { save(); load(name); }

    public static void reset() { applyDefaults(); save(); message = "Reset '" + active + "' to defaults."; }

    /** Server profiles: a profile JSON may contain {"server":"play.example.net"}; it is loaded on join. */
    private static String serverOf(String name) {
        try {
            if (!Files.exists(file(name))) return null;
            JsonObject o = JsonParser.parseString(Files.readString(file(name))).getAsJsonObject();
            return o.has("server") ? o.get("server").getAsString() : null;
        } catch (Exception e) { return null; }
    }

    public static void onJoin(MinecraftClient mc) {
        if (mc.getCurrentServerEntry() == null) return;
        String addr = mc.getCurrentServerEntry().address.toLowerCase(Locale.ROOT);
        for (String p : list()) {
            String s = serverOf(p);
            if (s != null && !s.isBlank() && addr.contains(s.toLowerCase(Locale.ROOT)) && !p.equals(active)) { switchTo(p); return; }
        }
    }

    // --- import / export --------------------------------------------------------------------------
    public static void export() {
        save();
        try { Files.copy(file(active), root.resolve("export.json"), StandardCopyOption.REPLACE_EXISTING); message = "Exported to config/noctis/export.json"; }
        catch (IOException e) { message = "Export failed: " + e.getMessage(); }
    }

    public static void importFile() {
        Path in = root.resolve("import.json");
        if (!Files.exists(in)) { message = "Place a file at config/noctis/import.json first."; return; }
        try {
            JsonObject o = JsonParser.parseString(Files.readString(in, StandardCharsets.UTF_8)).getAsJsonObject();
            String name = o.has("profile") ? o.get("profile").getAsString().replaceAll("[^A-Za-z0-9_-]", "") : "imported";
            if (name.isEmpty() || name.length() > 32) name = "imported";
            if (name.equals(DEFAULT_PROFILE) || name.equals(PRIVATE_TEST_PROFILE)) name = "imported-" + name;
            save();
            warnings.clear();
            apply(o);          // validates every value, throws on structural problems
            active = name;
            pendingServer = o.has("server") && o.get("server").isJsonPrimitive() ? o.get("server").getAsString() : null;
            try { write(name); } finally { pendingServer = null; }
            saveState();
            message = "Imported as '" + name + "'" + (warnings.isEmpty() ? "." : " (" + warnings.size() + " value(s) repaired).");
        } catch (Exception e) {
            message = "Import rejected: " + e.getMessage();
            load(active);
        }
    }
}
