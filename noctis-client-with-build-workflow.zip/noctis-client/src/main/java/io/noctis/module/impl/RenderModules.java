package io.noctis.module.impl;

import io.noctis.module.*;
import io.noctis.module.Module;
import io.noctis.setting.ModeSetting;
import io.noctis.setting.NumSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;

import static io.noctis.module.impl.Modules.unavailable;

public final class RenderModules {
    private RenderModules() {}

    static void register() {
        ModuleManager.register(new Fullbright());
        ModuleManager.register(new Ambience());
        ModuleManager.register(new PlayerESP());
        ModuleManager.register(new TargetESP());
        ModuleManager.register(new SwingSpeed());
        WorldRenderModules.register();

        Category c = Category.RENDER;
        String needs = "Needs a world-space render hook or a render mixin whose 1.21.11 signature has not been verified (no Minecraft jars available when this was written); an unverified mixin can crash the game at launch.";
        unavailable(c, Status.BLOCKED, "StorageESP", "Highlights containers through walls.", "Reviewed: highlighting containers through walls is hidden-information ESP. Not provided. (Search already outlines blocks you can see.)");
        unavailable(c, Status.BLOCKED, "Xray", "Makes terrain transparent.", "Reviewed: terrain transparency exposes hidden ore and caves. Not provided, including in single-player worlds shared over LAN.");
    }

    // ------------------------------------------------------------------------------------------
    public static final class Fullbright extends Module {
        private boolean applied;
        public Fullbright() { super("Fullbright", "Maximum brightness via a client-side night-vision effect (cosmetic; the server is not told).", Category.RENDER, Status.IMPLEMENTED); }
        @Override protected void onTick() {
            var p = player();
            StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 400) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, true, false, false));
                applied = true;
            }
        }
        @Override protected void onDisable() {
            if (applied && mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            applied = false;
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class Ambience extends Module {
        private final ModeSetting weather = add(new ModeSetting("Weather", "Client-side weather", "Clear", "Clear", "Rain", "Thunder"));
        public Ambience() { super("Ambience", "Overrides weather visuals on your client only. (Time-of-day control is not implemented.)", Category.RENDER, Status.IMPLEMENTED); }
        @Override protected void onTick() {
            var w = mc.world;
            float rain = weather.is("Clear") ? 0f : 1f, thunder = weather.is("Thunder") ? 1f : 0f;
            w.setRainGradient(rain);
            w.setThunderGradient(thunder);
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class PlayerESP extends Module {
        private final NumSetting range = add(new NumSetting("Range", "Maximum distance (blocks)", 64, 8, 128, 1));
        public PlayerESP() { super("PlayerESP", "Outlines other players with the vanilla glow effect, including through walls. Singleplayer test worlds only.", Category.RENDER, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            for (Entity e : mc.world.getEntities()) {
                if (e instanceof PlayerEntity pe && pe != mc.player) e.setGlowing(mc.player.distanceTo(pe) <= range.val());
            }
        }
        @Override protected void onDisable() {
            if (mc.world == null) return;
            for (Entity e : mc.world.getEntities()) if (e instanceof PlayerEntity pe && pe != mc.player) e.setGlowing(false);
        }
    }

    // ------------------------------------------------------------------------------------------
    /** Glow outline on the entity under your crosshair. That entity is by definition visible, so no hidden information is shown. */
    public static final class TargetESP extends Module {
        private Entity glowing;
        public TargetESP() { super("TargetESP", "Outlines the living entity under your crosshair with the vanilla glow effect (client-side).", Category.RENDER, Status.IMPLEMENTED); }
        @Override protected void onTick() {
            Entity t = mc.targetedEntity instanceof net.minecraft.entity.LivingEntity ? mc.targetedEntity : null;
            if (t != glowing) { clear(); glowing = t; }
            if (glowing != null) glowing.setGlowing(true);
        }
        private void clear() { if (glowing != null) glowing.setGlowing(false); glowing = null; }
        @Override protected void onDisable() { clear(); }
    }

    // ------------------------------------------------------------------------------------------
    /** Visual only: advances your swing animation faster. It does not change attack cooldown or damage. */
    public static final class SwingSpeed extends Module {
        private final NumSetting extra = add(new NumSetting("Extra ticks", "Extra animation ticks per tick while swinging (vanilla swing is 6 ticks)", 1, 0, 3, 1));
        public SwingSpeed() { super("SwingSpeed", "Plays your hand-swing animation faster (visual only).", Category.RENDER, Status.IMPLEMENTED); }
        @Override protected void onTick() {
            var p = player();
            if (p.handSwinging) p.handSwingTicks += extra.intVal();
        }
    }
}
