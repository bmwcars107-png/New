package io.noctis.module;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.*;

public final class ModuleManager {
    private static final List<Module> ALL = new ArrayList<>();
    private static final Map<String, Module> BY_NAME = new HashMap<>();
    private static final Set<Module> HELD = new HashSet<>();

    private ModuleManager() {}

    public static void register(Module m) {
        if (BY_NAME.putIfAbsent(m.name.toLowerCase(Locale.ROOT), m) != null)
            throw new IllegalStateException("Duplicate module name: " + m.name);
        ALL.add(m);
    }

    public static Module get(String name) { return BY_NAME.get(name.toLowerCase(Locale.ROOT)); }
    public static List<Module> all() { return Collections.unmodifiableList(ALL); }

    public static List<Module> in(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) if (m.category == c) out.add(m);
        return out;
    }

    /** Single dispatch point: keybinds, safety re-checks and per-tick logic. */
    public static void tick(MinecraftClient mc) {
        long window = mc.getWindow().getHandle();
        boolean canBind = mc.currentScreen == null;
        for (Module m : ALL) {
            int k = m.key();
            if (k > 0 && canBind) {
                boolean down = GLFW.glfwGetKey(window, k) == GLFW.GLFW_PRESS;
                if (down && HELD.add(m)) m.toggle();
                else if (!down) HELD.remove(m);
            }
            if (!m.isEnabled() || m.action) continue;
            String reason = m.blockedReason(); // e.g. joined a multiplayer server with a private-test module on
            if (reason != null) { m.setEnabled(false); m.notice = reason; continue; }
            if (mc.player != null) m.safeTick();
        }
    }

    public static void disableAll() {
        for (Module m : ALL) if (m.isEnabled()) m.setEnabled(false);
    }

    public static void clearTransient() {
        HELD.clear();
        for (Module m : ALL) m.clearTransient();
    }
}
