package io.noctis.module.impl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

import java.util.function.Predicate;

/** Small inventory helpers shared by modules. */
final class Inv {
    private Inv() {}

    static int hotbar(Predicate<ItemStack> p) {
        var pl = MinecraftClient.getInstance().player;
        if (pl == null) return -1;
        for (int i = 0; i < 9; i++) if (p.test(pl.getInventory().getStack(i))) return i;
        return -1;
    }

    static void select(int slot) {
        var pl = MinecraftClient.getInstance().player;
        if (pl != null && slot >= 0 && slot < 9) pl.getInventory().setSelectedSlot(slot);
    }

    static int selected() {
        var pl = MinecraftClient.getInstance().player;
        return pl == null ? 0 : pl.getInventory().getSelectedSlot();
    }

    /** Container slot id of a PlayerInventory index inside the player's own screen handler. */
    static int handlerSlot(int invIndex) { return invIndex < 9 ? 36 + invIndex : invIndex; }

    /** Swap the contents of two container slots with three vanilla pickup clicks (works for armor/offhand slots too). */
    static void swapSlots(int a, int b) {
        var mc = MinecraftClient.getInstance();
        var p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        int id = p.playerScreenHandler.syncId;
        mc.interactionManager.clickSlot(id, a, 0, net.minecraft.screen.slot.SlotActionType.PICKUP, p);
        mc.interactionManager.clickSlot(id, b, 0, net.minecraft.screen.slot.SlotActionType.PICKUP, p);
        mc.interactionManager.clickSlot(id, a, 0, net.minecraft.screen.slot.SlotActionType.PICKUP, p);
    }

    /** Set a key binding to whatever the physical key is doing right now (used when a module stops forcing it). */
    static void restoreKey(net.minecraft.client.option.KeyBinding k) {
        var mc = MinecraftClient.getInstance();
        int code = net.minecraft.client.util.InputUtil.fromTranslationKey(k.getBoundKeyTranslationKey()).getCode();
        k.setPressed(mc.currentScreen == null && org.lwjgl.glfw.GLFW.glfwGetKey(mc.getWindow().getHandle(), code) == org.lwjgl.glfw.GLFW.GLFW_PRESS);
    }

    static void say(String msg) {
        var pl = MinecraftClient.getInstance().player;
        if (pl != null) pl.sendMessage(Text.literal("\u00a75[Noctis]\u00a7r " + msg), false);
    }
}
