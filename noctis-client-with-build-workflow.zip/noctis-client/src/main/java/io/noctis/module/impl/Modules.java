package io.noctis.module.impl;

import io.noctis.module.*;
import io.noctis.module.Module;

/** Registers the full catalogue. Implemented modules live in the per-category classes. */
public final class Modules {
    private Modules() {}

    public static void registerAll() {
        CombatModules.register();
        MovementModules.register();
        PlayerModules.register();
        MacroModules.register();
        RenderModules.register();
        HudModules.register();
        MiscModules.register();
        ExtraModules.register();
        applyScopes();
    }

    /**
     * Private-test modules that only affect the local player (or the local player's own containers/blocks)
     * may also run in your own world while LAN guests are online. Modules that can hit, push or blow up
     * other players stay solo-only; combat modules that pick targets additionally refuse to target players
     * (see Module.mayTarget). Nothing here is ever relaxed on a remote server.
     */
    private static void applyScopes() {
        for (String n : new String[]{"GuiWalk", "Speed", "Step", "NoJumpDelay", "SnapTap", "NoWeb",
                "AutoTotem", "FastPlace", "NoBreakDelay", "FastEXP", "Replenish", "TotemRefill", "SmartPot",
                "ChestStealer", "Tunneler", "AimAssist", "TriggerBot", "ShieldBreaker", "AutoMace",
                "Criticals", "Hitbox", "SpearReach"}) {
            Module m = ModuleManager.get(n);
            if (m != null) m.scope = Module.Scope.HOST_WORLD;
        }
    }

    static void unavailable(Category c, Status s, String name, String description, String reason) {
        ModuleManager.register(new UnavailableModule(name, c, s, description, reason));
    }
}
