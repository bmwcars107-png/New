package io.noctis.module.impl;

import io.noctis.hud.HudElements;
import io.noctis.module.ModuleManager;

final class HudModules {
    private HudModules() {}

    static void register() { HudElements.create().forEach(ModuleManager::register); }
}
