package io.noctis.module.impl;

import io.noctis.NoctisClient;
import io.noctis.hooks.CapeHook;
import io.noctis.hooks.MoveFixHook;
import io.noctis.hooks.NametagHook;
import io.noctis.hooks.ViewModelHook;
import io.noctis.module.*;
import io.noctis.module.Module;
import io.noctis.render.Render3D;
import io.noctis.setting.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * The six modules that used to be placeholders: Capes, MoveFix, Nametags, AttributeMine, PearlCatch, ViewModel.
 * The four that need a render/input mixin talk to it through io.noctis.hooks.*, which the mixins (all in the optional
 * noctis-extra.mixins.json) call. Each hook counts its invocations, so a module can tell the user when its mixin did
 * not apply instead of silently doing nothing.
 */
public final class ExtraModules {
    private ExtraModules() {}

    public static ViewModel VIEW_MODEL;
    public static Capes CAPES;
    public static Nametags NAMETAGS;
    public static MoveFix MOVE_FIX;

    static void register() {
        ModuleManager.register(VIEW_MODEL = new ViewModel());
        ModuleManager.register(CAPES = new Capes());
        ModuleManager.register(NAMETAGS = new Nametags());
        ModuleManager.register(MOVE_FIX = new MoveFix());
        ModuleManager.register(new AttributeMine());
        ModuleManager.register(new PearlCatch());
        ModuleManager.register(new KnockbackDisplace());
    }

    private static int argb(int a, int rgb) { return (a << 24) | (rgb & 0xFFFFFF); }

    // ------------------------------------------------------------------------------------------
    /** Hook-liveness helper: true when a hook counter did not move for the given number of ticks while it should have. */
    private static final class Liveness {
        private long last = -1; private int still;
        boolean dead(long calls, boolean shouldBeFiring, int ticks) {
            if (!shouldBeFiring || calls != last) { last = calls; still = 0; return false; }
            return ++still >= ticks;
        }
    }

    // ------------------------------------------------------------------------------------------
    /** First-person held item position / rotation / scale. Cosmetic; changes nothing the server sees. */
    public static final class ViewModel extends Module {
        private final ModeSetting hands = add(new ModeSetting("Hands", "Which hand to transform", "Both", "Both", "Main hand", "Off hand"));
        private final NumSetting x = add(new NumSetting("X", "Sideways offset (+ = away from your body)", 0, -1.0, 1.0, 0.01));
        private final NumSetting y = add(new NumSetting("Y", "Vertical offset", 0, -1.0, 1.0, 0.01));
        private final NumSetting z = add(new NumSetting("Z", "Depth offset (+ = toward you)", 0, -1.5, 1.0, 0.01));
        private final NumSetting scale = add(new NumSetting("Scale", "Item size multiplier", 1.0, 0.2, 2.0, 0.01));
        private final NumSetting rx = add(new NumSetting("Rotate X", "Pitch (degrees)", 0, -180, 180, 1));
        private final NumSetting ry = add(new NumSetting("Rotate Y", "Yaw (degrees)", 0, -180, 180, 1));
        private final NumSetting rz = add(new NumSetting("Rotate Z", "Roll (degrees)", 0, -180, 180, 1));
        private final Liveness live = new Liveness();

        public ViewModel() { super("ViewModel", "Moves, rotates and scales the item in your first-person hands (cosmetic, client-side). Needs the HeldItemRenderer mixin; the module tells you if it did not apply.", Category.RENDER, Status.IMPLEMENTED); }

        public boolean appliesTo(Hand h) { return hands.is("Both") || (hands.is("Main hand") == (h == Hand.MAIN_HAND)); }
        public float x() { return x.floatVal(); }
        public float y() { return y.floatVal(); }
        public float z() { return z.floatVal(); }
        public float scale() { return scale.floatVal(); }
        public float rotX() { return rx.floatVal(); }
        public float rotY() { return ry.floatVal(); }
        public float rotZ() { return rz.floatVal(); }

        @Override protected void onTick() {
            boolean first = mc.options.getPerspective().isFirstPerson() && !mc.options.hudHidden;
            boolean holding = !player().getMainHandStack().isEmpty() || !player().getOffHandStack().isEmpty();
            notice = live.dead(ViewModelHook.calls, first && holding && mc.currentScreen == null, 200)
                    ? "Render hook inactive: the HeldItemRenderer mixin did not apply (see latest.log)." : "";
        }
    }

    // ------------------------------------------------------------------------------------------
    /**
     * Local-only cape cosmetic: other players never see it. Bundled presets are normal resource textures
     * (assets/noctis/textures/capes/*.png); a custom cape is any PNG in config/noctis/capes/ whose size is 64x32 or an
     * exact 2:1 multiple (128x64 ...). 22x17 legacy capes are not converted.
     */
    public static final class Capes extends Module {
        private static final String[] PRESETS = {"Noctis", "Crimson", "Frost", "Obsidian"};
        private final ModeSetting cape = add(new ModeSetting("Cape", "Bundled design or a PNG from config/noctis/capes/", "Noctis", "Noctis", "Crimson", "Frost", "Obsidian", "Custom file"));
        private final StrSetting file = add(new StrSetting("Custom file", "File name inside config/noctis/capes/ (letters, digits, . _ - only)", "cape.png", 48));
        private final BoolSetting elytra = add(new BoolSetting("Match elytra", "Use the same texture on your elytra", false));
        private final Map<String, Identifier> loaded = new HashMap<>();
        private final Liveness live = new Liveness();
        private String customError = "";

        public Capes() {
            super("Capes", "Shows a cape of your choice on YOUR character (client-side only; nobody else sees it). Presets or a PNG from config/noctis/capes/.", Category.MISC, Status.IMPLEMENTED);
            file.showIf(() -> cape.is("Custom file"));
        }

        public boolean matchElytra() { return elytra.on(); }

        /** Texture to draw, or null (vanilla cape) when nothing valid is selected. */
        public Identifier textureId() {
            String c = cape.get();
            if (!c.equals("Custom file")) return Identifier.of("noctis", "textures/capes/" + c.toLowerCase(Locale.ROOT) + ".png");
            return custom(file.get());
        }

        private Identifier custom(String name) {
            if (!name.matches("[A-Za-z0-9._-]{1,48}") || !name.toLowerCase(Locale.ROOT).endsWith(".png") || name.contains("..")) {
                customError = "Invalid file name (use letters, digits, . _ - and end with .png).";
                return null;
            }
            try {
                Path f = FabricLoader.getInstance().getConfigDir().resolve("noctis").resolve("capes").resolve(name).normalize();
                if (!Files.isRegularFile(f)) { customError = "Not found: config/noctis/capes/" + name; return null; }
                String key = name + "@" + Files.getLastModifiedTime(f).toMillis();
                Identifier known = loaded.get(key);
                if (known != null) return known;
                NativeImage img;
                try (InputStream in = Files.newInputStream(f)) { img = NativeImage.read(in); }
                int w = img.getWidth(), h = img.getHeight();
                if (w < 64 || w > 1024 || w % 64 != 0 || h != w / 2) {
                    img.close();
                    customError = "Cape must be 64x32 or an exact 2:1 multiple (got " + w + "x" + h + ").";
                    return null;
                }
                Identifier id = Identifier.of("noctis", "dynamic/cape_" + Integer.toHexString(key.hashCode()));
                mc.getTextureManager().registerTexture(id, new NativeImageBackedTexture(() -> "noctis_cape", img));
                loaded.put(key, id);
                customError = "";
                return id;
            } catch (Exception e) {
                customError = "Could not read cape: " + e.getClass().getSimpleName();
                NoctisClient.LOG.warn("Capes: {}", e.toString());
                return null;
            }
        }

        @Override protected void onTick() {
            boolean third = !mc.options.getPerspective().isFirstPerson();
            if (cape.is("Custom file")) textureId(); // reload / re-validate (cached by file time)
            if (cape.is("Custom file") && !customError.isEmpty()) { notice = customError; return; }
            notice = live.dead(CapeHook.calls, third, 200) ? "Render hook inactive: the CapeFeatureRenderer mixin did not apply (see latest.log)." : "";
        }
    }

    // ------------------------------------------------------------------------------------------
    /**
     * Adds health, distance and ping to name labels vanilla already decided to draw. It never makes a hidden
     * entity visible. Label size/background are vanilla (changing them needs a label-render mixin that is not done).
     */
    public static final class Nametags extends Module {
        private final BoolSetting health = add(new BoolSetting("Health", "Append current health (+absorption), coloured by percentage", true));
        private final BoolSetting distance = add(new BoolSetting("Distance", "Append distance in blocks", false));
        private final BoolSetting ping = add(new BoolSetting("Ping", "Append the player-list latency (players only)", false));
        private final BoolSetting mobs = add(new BoolSetting("Mobs", "Also decorate labels of named mobs, not only players", false));
        private final Liveness live = new Liveness();

        public Nametags() { super("Nametags", "Extends vanilla name labels with health, distance and ping. Only edits labels vanilla already shows (no extra visibility). Label size is vanilla.", Category.RENDER, Status.IMPLEMENTED); }

        public boolean health() { return health.on(); }
        public boolean distance() { return distance.on(); }
        public boolean ping() { return ping.on(); }
        public boolean mobs() { return mobs.on(); }

        @Override protected void onTick() {
            notice = live.dead(NametagHook.calls, mc.world != null && mc.world.getPlayers().size() > 1, 200)
                    ? "Render hook inactive: the EntityRenderer mixin did not apply (see latest.log)." : "";
        }
    }

    // ------------------------------------------------------------------------------------------
    /**
     * Keeps your direction of travel when a Noctis module (AimAssist) turns the view: the movement input of the next
     * tick is rotated by the opposite angle. Without such a module it does nothing. Noctis has no silent rotations,
     * so there is no server-side rotation to correct.
     */
    public static final class MoveFix extends Module {
        private final NumSetting strength = add(new NumSetting("Strength %", "Share of the view rotation that is compensated", 100, 0, 100, 5));
        private final Liveness live = new Liveness();
        private volatile float pending;

        public MoveFix() {
            super("MoveFix", "Keeps your walking direction steady while AimAssist turns your view (rotates the movement input by the opposite angle). Does nothing on its own.", Category.MOVEMENT, Status.PRIVATE_TEST);
            scope = Scope.HOST_WORLD;
        }

        /** Called by AimAssist after it changed the yaw by deltaDegrees. */
        public static void note(float deltaDegrees) {
            MoveFix m = MOVE_FIX;
            if (m != null && m.isEnabled()) m.pending += deltaDegrees * (float) (m.strength.val() / 100.0);
        }

        /** Returns the accumulated rotation once, then resets it (read from the input mixin). */
        public float consume() { float d = pending; pending = 0f; return d; }

        @Override protected void onDisable() { pending = 0f; }
        @Override protected void onTick() {
            notice = live.dead(MoveFixHook.calls, mc.currentScreen == null, 100) ? "Input hook inactive: the KeyboardInput mixin did not apply (see latest.log)." : "";
        }
    }

    // ------------------------------------------------------------------------------------------
    /**
     * Picks the hotbar slot with the highest REAL block-breaking progress per tick for the block you are mining, using
     * vanilla's own calculation with each candidate temporarily selected (nothing is sent to the server during the test).
     * Limit: bonuses that vanilla only applies to the attribute map after the slot change (e.g. Efficiency through
     * attribute modifiers) are not visible to the test for the not-yet-held stack; AutoTool's tool-speed pick is
     * a good complement.
     */
    public static final class AttributeMine extends Module {
        private final BoolSetting back = add(new BoolSetting("Switch back", "Return to the previous slot when you stop mining", true));
        private final NumSetting minGain = add(new NumSetting("Min gain %", "Only switch if the candidate breaks at least this much faster", 10, 0, 200, 5));
        private final NumSetting minDurability = add(new NumSetting("Min durability %", "Never switch to a damageable tool below this durability", 5, 0, 50, 1));
        private int previous = -1;

        public AttributeMine() { super("AttributeMine", "Switches to the hotbar slot that breaks the targeted block fastest according to vanilla's own break-progress calculation, skipping nearly broken tools.", Category.PLAYER, Status.IMPLEMENTED); }

        private float progress(BlockState st, BlockPos pos, int slot) {
            int cur = Inv.selected();
            Inv.select(slot);
            try { return st.calcBlockBreakingDelta(player(), mc.world, pos); }
            finally { Inv.select(cur); }
        }

        @Override protected void onTick() {
            if (mc.currentScreen == null && mc.options.attackKey.isPressed()
                    && mc.crosshairTarget instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
                BlockPos pos = hit.getBlockPos();
                BlockState st = mc.world.getBlockState(pos);
                if (st.isAir()) return;
                int cur = Inv.selected();
                float best = progress(st, pos, cur);
                int bestSlot = -1;
                for (int i = 0; i < 9; i++) {
                    if (i == cur) continue;
                    ItemStack s = player().getInventory().getStack(i);
                    if (s.isDamageable() && s.getMaxDamage() > 0
                            && (s.getMaxDamage() - s.getDamage()) * 100.0 / s.getMaxDamage() < minDurability.val()) continue;
                    float p = progress(st, pos, i);
                    if (p > best * (1.0 + minGain.val() / 100.0) && p > 0f) { best = p; bestSlot = i; }
                }
                if (bestSlot >= 0) { if (previous < 0) previous = cur; Inv.select(bestSlot); }
            } else if (previous >= 0) {
                if (back.on()) Inv.select(previous);
                previous = -1;
            }
        }
        @Override protected void onDisable() { if (previous >= 0 && back.on() && mc.player != null) Inv.select(previous); previous = -1; }
    }

    // ------------------------------------------------------------------------------------------
    /**
     * Tracks the ender pearls YOU threw: draws the predicted flight path and landing spot and warns once per pearl when
     * the landing is dangerous (void, lava, fire, or lethal fall). It does not steer, cancel or automate anything.
     */
    public static final class PearlCatch extends Module implements Render3D.WorldRenderable {
        private final ColorSetting color = add(new ColorSetting("Colour", "Path colour", 0xB57BFF));
        private final BoolSetting warn = add(new BoolSetting("Landing warning", "Show an action-bar warning for a dangerous landing", true));
        private final NumSetting steps = add(new NumSetting("Max steps", "Simulated ticks", 160, 40, 300, 10));
        private final Set<Integer> warned = new HashSet<>();

        public PearlCatch() { super("PearlCatch", "Follows your own thrown ender pearls: path + landing marker, and a warning when the landing is over void/lava/fire or too far down. Informational only.", Category.MACROS, Status.IMPLEMENTED); }

        private record Result(Vec3d end, boolean hitBlock) {}

        private Result simulate(EnderPearlEntity pearl, java.util.List<Vec3d> path) {
            Vec3d pos = pearl.getPos(), vel = pearl.getVelocity();
            path.add(pos);
            for (int i = 0; i < steps.intVal(); i++) {
                Vec3d next = pos.add(vel);
                var hit = mc.world.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, pearl));
                boolean stop = hit.getType() != HitResult.Type.MISS;
                if (stop) next = hit.getPos();
                path.add(next);
                if (stop) return new Result(next, true);
                pos = next;
                vel = vel.multiply(0.99).subtract(0, 0.03, 0);
                if (pos.y < mc.world.getBottomY() - 8) return new Result(pos, false);
            }
            return new Result(pos, false);
        }

        private String danger(Result r) {
            if (!r.hitBlock()) return "no landing found (void?)";
            BlockPos land = BlockPos.ofFloored(r.end());
            for (int dy = 0; dy >= -1; dy--) {
                BlockPos bp = land.add(0, dy, 0);
                if (mc.world.getFluidState(bp).isIn(FluidTags.LAVA)) return "lava";
                BlockState st = mc.world.getBlockState(bp);
                if (st.isOf(Blocks.FIRE) || st.isOf(Blocks.SOUL_FIRE) || st.isOf(Blocks.MAGMA_BLOCK) || st.isOf(Blocks.CACTUS)) return "fire/hazard block";
            }
            int fall = 0;
            BlockPos q = land;
            while (fall < 64 && q.getY() > mc.world.getBottomY() && mc.world.getBlockState(q).getCollisionShape(mc.world, q).isEmpty()
                    && mc.world.getFluidState(q).isEmpty()) { q = q.down(); fall++; }
            if (q.getY() <= mc.world.getBottomY()) return "void";
            double dmg = 5.0 + Math.max(0, fall - 3); // vanilla pearl arrival damage is 5, plus fall damage
            if (dmg >= player().getHealth() + player().getAbsorptionAmount()) return "lethal landing damage (~" + (int) dmg + ")";
            return null;
        }

        @Override protected void onTick() {
            Set<Integer> alive = new HashSet<>();
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof EnderPearlEntity pearl) || pearl.getOwner() != mc.player) continue;
                alive.add(pearl.getId());
                if (warn.on() && warned.add(pearl.getId())) {
                    String d = danger(simulate(pearl, new java.util.ArrayList<>()));
                    if (d != null) player().sendMessage(Text.literal("\u00a7cPearl landing: " + d), true);
                }
            }
            warned.retainAll(alive);
        }

        @Override protected void onDisable() { warned.clear(); }

        @Override public void renderWorld(Render3D.Frame f) {
            if (mc.world == null) return;
            int col = argb(0xC0, color.rgb());
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof EnderPearlEntity pearl) || pearl.getOwner() != mc.player) continue;
                java.util.List<Vec3d> path = new java.util.ArrayList<>();
                Result r = simulate(pearl, path);
                for (int i = 1; i < path.size(); i++) f.line(path.get(i - 1), path.get(i), col, 0.05);
                if (r.hitBlock()) f.fillBox(new Box(r.end(), r.end()).expand(0.2), argb(0xA0, danger(r) == null ? 0x55FF55 : 0xFF5555));
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    /**
     * Reviewed module #4 of the "unavailable" list: implemented as a solo-only private-world toy. It turns (and
     * optionally scales) the knockback YOU receive in your own empty world. It never touches other players and is
     * refused as soon as a LAN guest joins or you are on a remote server.
     */
    public static final class KnockbackDisplace extends Module {
        private final NumSetting rotate = add(new NumSetting("Rotate", "Degrees to rotate the horizontal knockback (+ = clockwise seen from above)", 0, -180, 180, 5));
        private final NumSetting horizontal = add(new NumSetting("Horizontal %", "Share of horizontal knockback you keep", 100, 0, 200, 5));
        private Vec3d prev = Vec3d.ZERO;

        public KnockbackDisplace() {
            super("KnockbackDisplace", "Rotates / scales the knockback you take on the first tick after a hit. Alone in your own world only.", Category.COMBAT, Status.PRIVATE_TEST);
            conflicts.add("Velocity");
        }

        @Override protected void onEnable() { prev = mc.player == null ? Vec3d.ZERO : mc.player.getVelocity(); }

        @Override protected void onTick() {
            var p = player();
            Vec3d cur = p.getVelocity();
            if (p.hurtTime > 0 && p.hurtTime == p.maxHurtTime) {
                Vec3d d = cur.subtract(prev);
                double r = Math.toRadians(rotate.val()), c = Math.cos(r), s = Math.sin(r), k = horizontal.val() / 100.0;
                double dx = (d.x * c - d.z * s) * k, dz = (d.x * s + d.z * c) * k;
                p.setVelocity(prev.x + dx, cur.y, prev.z + dz);
                cur = p.getVelocity();
            }
            prev = cur;
        }
    }
}
