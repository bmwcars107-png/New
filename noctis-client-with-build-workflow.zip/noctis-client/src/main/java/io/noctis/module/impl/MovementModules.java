package io.noctis.module.impl;

import io.noctis.gui.ClickGuiScreen;
import io.noctis.gui.HudEditorScreen;
import io.noctis.mixin.LivingEntityAccessor;
import io.noctis.module.*;
import io.noctis.module.Module;
import io.noctis.setting.BoolSetting;
import io.noctis.setting.NumSetting;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.ingame.AbstractSignEditScreen;
import net.minecraft.client.gui.screen.ingame.AnvilScreen;
import net.minecraft.client.gui.screen.ingame.BookEditScreen;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import static io.noctis.module.impl.Modules.unavailable;

public final class MovementModules {
    private MovementModules() {}

    static void register() {
        ModuleManager.register(new Sprint());
        ModuleManager.register(new AutoWalk());
        ModuleManager.register(new GuiWalk());
        ModuleManager.register(new Speed());
        ModuleManager.register(new Step());
        ModuleManager.register(new NoJumpDelay());
        ModuleManager.register(new FastStairs());
        ModuleManager.register(new SnapTap());
        ModuleManager.register(new KeepSprint());
        ModuleManager.register(new JumpReset());
        ModuleManager.register(new Velocity());
        ModuleManager.register(new NoWeb());

        Category c = Category.MOVEMENT;
        unavailable(c, Status.BLOCKED, "ComboHelper", "Combo-keeping assistance.", "Reviewed: combo-keeping assistance only has meaning against other players; it is unfair combat manipulation. Deliberately unavailable.");
        unavailable(c, Status.BLOCKED, "NoLungeCooldown", "Removes the spear lunge cooldown.", "Reviewed: the lunge cooldown is enforced by the server, so a client-side bypass either desyncs or is a combat advantage on a LAN/remote world. Deliberately unavailable.");
        unavailable(c, Status.PLANNED, "NoSlow", "Removes item-use slowdown.", "Reviewed: acceptable as an own-world convenience, but the slowdown is applied inside ClientPlayerEntity movement code and its 1.21.11 Yarn hook could not be verified from this sandbox (only pre-1.17 and mapping-history pages were reachable). On remote servers it would bypass movement rules, so it would stay own-world only. Planned.");
        unavailable(c, Status.PLANNED, "TimerExploit", "Speeds up the game timer.", "Reviewed: a game-speed multiplier is acceptable alone in your own world, but the RenderTickCounter.Dynamic hook for 1.21.11 could not be verified here; client-side speed-up is a movement-rule bypass on any other server. Would be SOLO-only. Planned.");
    }

    static boolean moving() {
        var o = net.minecraft.client.MinecraftClient.getInstance().options;
        return o.forwardKey.isPressed() || o.backKey.isPressed() || o.leftKey.isPressed() || o.rightKey.isPressed();
    }

    // ------------------------------------------------------------------------------------------
    public static final class Sprint extends Module {
        private final BoolSetting hungerCheck = add(new BoolSetting("Respect hunger", "Do not sprint when hunger is too low", true));
        public Sprint() { super("Sprint", "Automatically sprints while you hold forward (a toggle-sprint convenience).", Category.MOVEMENT, Status.IMPLEMENTED); }
        @Override protected void onTick() {
            var p = player();
            if (!mc.options.forwardKey.isPressed() || p.isSneaking() || p.horizontalCollision || p.isUsingItem()) return;
            if (hungerCheck.on() && p.getHungerManager().getFoodLevel() <= 6 && !p.getAbilities().allowFlying) return;
            p.setSprinting(true);
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class AutoWalk extends Module {
        public AutoWalk() { super("AutoWalk", "Holds the forward key for you. Disable it (or press forward) to stop.", Category.MOVEMENT, Status.IMPLEMENTED); }
        @Override protected void onTick() { if (mc.currentScreen == null) mc.options.forwardKey.setPressed(true); }
        @Override protected void onDisable() {
            int code = InputUtil.fromTranslationKey(mc.options.forwardKey.getBoundKeyTranslationKey()).getCode();
            boolean physical = GLFW.glfwGetKey(mc.getWindow().getHandle(), code) == GLFW.GLFW_PRESS;
            mc.options.forwardKey.setPressed(physical);
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class GuiWalk extends Module {
        public GuiWalk() { super("GuiWalk", "Keep moving while inventories and containers are open (never in chat, signs, anvils or this GUI). Singleplayer test worlds only.", Category.MOVEMENT, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            var s = mc.currentScreen;
            if (s == null || s instanceof ChatScreen || s instanceof ClickGuiScreen || s instanceof HudEditorScreen
                    || s instanceof AnvilScreen || s instanceof AbstractSignEditScreen || s instanceof BookEditScreen
                    || s instanceof CreativeInventoryScreen) return;
            long win = mc.getWindow().getHandle();
            for (KeyBinding k : new KeyBinding[]{mc.options.forwardKey, mc.options.backKey, mc.options.leftKey, mc.options.rightKey, mc.options.jumpKey}) {
                int code = InputUtil.fromTranslationKey(k.getBoundKeyTranslationKey()).getCode();
                k.setPressed(GLFW.glfwGetKey(win, code) == GLFW.GLFW_PRESS);
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class Speed extends Module {
        private final NumSetting factor = add(new NumSetting("Multiplier", "Per-tick ground speed multiplier", 1.1, 1.0, 1.5, 0.01));
        private final NumSetting cap = add(new NumSetting("Max speed", "Horizontal speed cap (blocks/tick)", 0.35, 0.2, 0.8, 0.01));
        public Speed() { super("Speed", "Boosts ground movement speed up to a cap. Singleplayer test worlds only.", Category.MOVEMENT, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            var p = player();
            if (!p.isOnGround() || !moving()) return;
            Vec3d v = p.getVelocity();
            double nx = v.x * factor.val(), nz = v.z * factor.val(), h = Math.hypot(nx, nz);
            if (h > cap.val()) { nx *= cap.val() / h; nz *= cap.val() / h; }
            p.setVelocity(nx, v.y, nz);
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class Step extends Module {
        private final NumSetting height = add(new NumSetting("Height", "Step height in blocks", 1.0, 0.6, 2.5, 0.1));
        public Step() { super("Step", "Raises your step height attribute so you walk up blocks. Singleplayer test worlds only.", Category.MOVEMENT, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            var a = player().getAttributeInstance(EntityAttributes.STEP_HEIGHT);
            if (a != null && a.getBaseValue() != height.val()) a.setBaseValue(height.val());
        }
        @Override protected void onDisable() {
            if (mc.player == null) return;
            var a = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
            if (a != null) a.setBaseValue(0.6);   // vanilla default
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class NoJumpDelay extends Module {
        public NoJumpDelay() { super("NoJumpDelay", "Removes the delay between jumps while holding jump. Singleplayer test worlds only.", Category.MOVEMENT, Status.PRIVATE_TEST); }
        @Override protected void onTick() { ((LivingEntityAccessor) player()).noctis$setJumpingCooldown(0); }
    }

    // ------------------------------------------------------------------------------------------
    /** Uses the vanilla "Auto-Jump" option so stairs and slabs are climbed without pressing jump. Restores your own setting on disable. */
    public static final class FastStairs extends Module {
        private Boolean previous;
        public FastStairs() { super("FastStairs", "Turns on vanilla Auto-Jump so you climb stairs and slabs smoothly; restores your previous setting when disabled.", Category.MOVEMENT, Status.IMPLEMENTED); }
        @Override protected void onEnable() {
            previous = mc.options.getAutoJump().getValue();
            mc.options.getAutoJump().setValue(true);
        }
        @Override protected void onTick() { if (!mc.options.getAutoJump().getValue()) mc.options.getAutoJump().setValue(true); }
        @Override protected void onDisable() {
            if (previous != null) mc.options.getAutoJump().setValue(previous);
            previous = null;
        }
    }

    // ------------------------------------------------------------------------------------------
    /** Last-key-wins for opposing movement keys (left/right, forward/back). Input cleanup only; no extra speed. */
    public static final class SnapTap extends Module {
        private long clock;
        private final long[] since = new long[4];
        private final boolean[] was = new boolean[4];
        public SnapTap() { super("SnapTap", "When two opposing movement keys are held, the most recently pressed one wins. Singleplayer test worlds only.", Category.MOVEMENT, Status.PRIVATE_TEST); conflicts.add("AutoWalk"); }

        private KeyBinding[] keys() { return new KeyBinding[]{mc.options.leftKey, mc.options.rightKey, mc.options.forwardKey, mc.options.backKey}; }

        @Override protected void onTick() {
            if (mc.currentScreen != null) return;
            clock++;
            KeyBinding[] k = keys();
            long win = mc.getWindow().getHandle();
            boolean[] down = new boolean[4];
            for (int i = 0; i < 4; i++) {
                int code = InputUtil.fromTranslationKey(k[i].getBoundKeyTranslationKey()).getCode();
                down[i] = GLFW.glfwGetKey(win, code) == GLFW.GLFW_PRESS;
                if (down[i] && !was[i]) since[i] = clock;
                was[i] = down[i];
            }
            for (int a = 0; a < 4; a += 2) {
                boolean first = down[a], second = down[a + 1];
                if (first && second) {
                    boolean firstWins = since[a] > since[a + 1];
                    k[a].setPressed(firstWins);
                    k[a + 1].setPressed(!firstWins);
                } else {
                    k[a].setPressed(first);
                    k[a + 1].setPressed(second);
                }
            }
        }
        @Override protected void onDisable() {
            if (mc.player == null) return;
            for (KeyBinding k : keys()) Inv.restoreKey(k);
            java.util.Arrays.fill(was, false);
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class KeepSprint extends Module {
        private boolean was;
        public KeepSprint() { super("KeepSprint", "Re-applies sprint if an attack stopped it while you still hold forward. Singleplayer test worlds only.", Category.MOVEMENT, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            var p = player();
            if (was && !p.isSprinting() && mc.options.attackKey.isPressed() && mc.options.forwardKey.isPressed()
                    && !p.isSneaking() && !p.horizontalCollision && p.getHungerManager().getFoodLevel() > 6) p.setSprinting(true);
            was = p.isSprinting();
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class JumpReset extends Module {
        public JumpReset() { super("JumpReset", "Jumps the moment you take damage while on the ground. Singleplayer test worlds only.", Category.MOVEMENT, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            var p = player();
            if (p.hurtTime > 0 && p.isOnGround() && mc.currentScreen == null) p.jump();
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class Velocity extends Module {
        private final NumSetting horizontal = add(new NumSetting("Horizontal %", "Share of horizontal knockback you keep", 0, 0, 100, 5));
        private final NumSetting vertical = add(new NumSetting("Vertical %", "Share of vertical knockback you keep", 0, 0, 100, 5));
        private Vec3d prev = Vec3d.ZERO;
        public Velocity() { super("Velocity", "Scales the knockback you receive on the first tick after a hit. Singleplayer test worlds only.", Category.MOVEMENT, Status.PRIVATE_TEST); }
        @Override protected void onEnable() { prev = mc.player == null ? Vec3d.ZERO : mc.player.getVelocity(); }
        @Override protected void onTick() {
            var p = player();
            Vec3d cur = p.getVelocity();
            if (p.hurtTime > 0 && p.hurtTime == p.maxHurtTime) {
                Vec3d d = cur.subtract(prev);
                p.setVelocity(prev.x + d.x * horizontal.val() / 100.0, prev.y + d.y * vertical.val() / 100.0, prev.z + d.z * horizontal.val() / 100.0);
                cur = p.getVelocity();
            }
            prev = cur;
        }
    }

    // ------------------------------------------------------------------------------------------
    /** Needs the optional EntityAccessor mixin (noctis-extra.mixins.json). If that mixin did not apply, the module disables itself after 3 errors. */
    public static final class NoWeb extends Module {
        public NoWeb() { super("NoWeb", "Ignores cobweb / berry-bush slowdown. Needs the optional extra mixin. Singleplayer test worlds only.", Category.MOVEMENT, Status.PRIVATE_TEST); }
        @Override protected void onTick() { ((io.noctis.mixin.EntityAccessor) player()).noctis$setMovementMultiplier(Vec3d.ZERO); }
    }
}
