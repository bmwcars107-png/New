package io.noctis.module.impl;

import io.noctis.module.*;
import io.noctis.module.Module;
import io.noctis.render.Render3D;
import io.noctis.setting.BoolSetting;
import io.noctis.setting.ColorSetting;
import io.noctis.setting.NumSetting;
import io.noctis.setting.StrSetting;
import net.minecraft.block.Block;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.CrossbowItem;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Render modules that need world-space drawing (via {@link Render3D}) or the camera entity.
 * All drawing goes through Render3D; nothing here uses mixins.
 * Compile status: names/descriptors checked against Yarn 1.21.11 mappings only. NOT compiled, NOT run.
 */
public final class WorldRenderModules {
    private WorldRenderModules() {}

    static void register() {
        ModuleManager.register(new Trajectory());
        ModuleManager.register(new LightESP());
        ModuleManager.register(new AimVisualizer());
        ModuleManager.register(new Search());
        ModuleManager.register(new Freecam());
        ModuleManager.register(new NoRender());
        ModuleManager.get("Freecam").scope = Module.Scope.HOST_WORLD;
        ModuleManager.get("NoRender").scope = Module.Scope.HOST_WORLD;
    }

    private static int argb(int alpha, int rgb) { return (alpha << 24) | (rgb & 0xFFFFFF); }

    // ------------------------------------------------------------------------------------------
    /** Predicted arc of the projectile you hold/draw. Block collisions only (no entity hits, no water drag). */
    public static final class Trajectory extends Module implements Render3D.WorldRenderable {
        private final ColorSetting color = add(new ColorSetting("Colour", "Arc colour", 0x55FFFF));
        private final NumSetting width = add(new NumSetting("Width", "Line width (blocks)", 0.04, 0.01, 0.15, 0.01));
        private final NumSetting steps = add(new NumSetting("Max steps", "Simulated ticks", 120, 20, 300, 10));

        public Trajectory() {
            super("Trajectory", "Draws the predicted path of the projectile you are holding or drawing (bow, crossbow, trident, ender pearl, snowball, egg, potion, XP bottle). Block hits only; the real arc can differ slightly (your own motion and water are not simulated).", Category.RENDER, Status.IMPLEMENTED);
        }

        private record Profile(double speed, double gravity, float pitchOffset) {}

        private Profile of(ItemStack st) {
            var p = mc.player;
            if (st.isEmpty()) return null;
            if (st.isOf(Items.BOW)) {
                if (!p.isUsingItem() || !p.getActiveItem().isOf(Items.BOW)) return null;
                double pull = (72000 - p.getItemUseTimeLeft()) / 20.0;
                double f = (pull * pull + pull * 2.0) / 3.0;
                if (f < 0.1) return null;
                return new Profile(Math.min(1.0, f) * 3.0, 0.05, 0f);
            }
            if (st.isOf(Items.CROSSBOW)) return CrossbowItem.isCharged(st) ? new Profile(3.15, 0.05, 0f) : null;
            if (st.isOf(Items.TRIDENT)) return new Profile(2.5, 0.05, 0f);
            if (st.isOf(Items.ENDER_PEARL) || st.isOf(Items.SNOWBALL) || st.isOf(Items.EGG)) return new Profile(1.5, 0.03, 0f);
            if (st.isOf(Items.SPLASH_POTION) || st.isOf(Items.LINGERING_POTION)) return new Profile(0.5, 0.05, -20f);
            if (st.isOf(Items.EXPERIENCE_BOTTLE)) return new Profile(0.7, 0.07, -20f);
            return null;
        }

        @Override public void renderWorld(Render3D.Frame f) {
            var p = mc.player;
            if (p == null || mc.world == null) return;
            Profile pr = of(p.getMainHandStack());
            if (pr == null) pr = of(p.getOffHandStack());
            if (pr == null) return;
            Vec3d pos = p.getEyePos().subtract(0, 0.1, 0);
            Vec3d vel = Vec3d.fromPolar(p.getPitch() + pr.pitchOffset(), p.getYaw()).multiply(pr.speed());
            int col = argb(0xD0, color.rgb());
            double w = width.val();
            for (int i = 0; i < steps.intVal(); i++) {
                Vec3d next = pos.add(vel);
                var hit = mc.world.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
                boolean stop = hit.getType() != HitResult.Type.MISS;
                if (stop) next = hit.getPos();
                f.line(pos, next, col, w);
                if (stop) { f.fillBox(new Box(next, next).expand(0.12), argb(0xA0, 0xFF5555)); return; }
                pos = next;
                vel = vel.multiply(0.99).subtract(0, pr.gravity(), 0);
                if (pos.y < mc.world.getBottomY()) return;
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    /** Marks nearby floor blocks whose block light is low (mob-spawn risk). Uses only light values your client already has. */
    public static final class LightESP extends Module implements Render3D.WorldRenderable {
        private final NumSetting radius = add(new NumSetting("Radius", "Scan radius (blocks)", 10, 4, 20, 1));
        private final NumSetting maxLight = add(new NumSetting("Max light", "Mark floors whose block light is at or below this", 0, 0, 7, 1));
        private final ColorSetting color = add(new ColorSetting("Colour", "Marker colour", 0xFF3030));
        private final List<BlockPos> spots = new ArrayList<>();
        private int timer;

        public LightESP() {
            super("LightESP", "Draws an X on floor blocks near you whose block light level is low (mobs can spawn there). Block light only; sky light / time of day are not considered.", Category.RENDER, Status.IMPLEMENTED);
        }

        @Override protected void onEnable() { timer = 0; spots.clear(); }
        @Override protected void onDisable() { spots.clear(); }

        @Override protected void onTick() {
            if (timer-- > 0) return;
            timer = 10;
            var w = mc.world;
            BlockPos c = player().getBlockPos();
            int r = radius.intVal();
            List<BlockPos> found = new ArrayList<>();
            outer:
            for (int dx = -r; dx <= r; dx++)
                for (int dz = -r; dz <= r; dz++)
                    for (int dy = -6; dy <= 6; dy++) {
                        BlockPos pos = c.add(dx, dy, dz);
                        if (!w.getBlockState(pos).isAir()) continue;
                        BlockPos below = pos.down();
                        if (!w.getBlockState(below).isSideSolidFullSquare(w, below, Direction.UP)) continue;
                        if (w.getLightLevel(LightType.BLOCK, pos) > maxLight.intVal()) continue;
                        found.add(pos);
                        if (found.size() >= 1500) break outer;
                    }
            synchronized (spots) { spots.clear(); spots.addAll(found); }
        }

        @Override public void renderWorld(Render3D.Frame f) {
            int col = argb(0xC0, color.rgb());
            synchronized (spots) {
                for (BlockPos b : spots) {
                    double x = b.getX(), y = b.getY() + 0.02, z = b.getZ();
                    f.line(new Vec3d(x + 0.15, y, z + 0.15), new Vec3d(x + 0.85, y, z + 0.85), col, 0.07);
                    f.line(new Vec3d(x + 0.85, y, z + 0.15), new Vec3d(x + 0.15, y, z + 0.85), col, 0.07);
                }
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    /** Shows where AimAssist is currently steering. Purely a display of AimAssist's own target. */
    public static final class AimVisualizer extends Module implements Render3D.WorldRenderable {
        private final ColorSetting color = add(new ColorSetting("Colour", "Line colour", 0xFFD040));

        public AimVisualizer() {
            super("AimVisualizer", "Draws a line and marker at the point AimAssist is aiming at (needs AimAssist enabled and a target).", Category.RENDER, Status.IMPLEMENTED);
        }

        @Override public void renderWorld(Render3D.Frame f) {
            Vec3d t = CombatModules.AimAssist.aimPoint;
            if (t == null || System.currentTimeMillis() - CombatModules.AimAssist.aimMillis > 250 || mc.player == null) return;
            int col = argb(0xC0, color.rgb());
            Vec3d from = mc.player.getEyePos().add(mc.player.getRotationVec(1f).multiply(0.6)).subtract(0, 0.15, 0);
            f.line(from, t, col, 0.03);
            f.fillBox(new Box(t, t).expand(0.1), col);
        }
    }

    // ------------------------------------------------------------------------------------------
    /** Highlights chosen block types, but ONLY those with a clear line of sight to your eyes. */
    public static final class Search extends Module implements Render3D.WorldRenderable {
        private final StrSetting blocks = add(new StrSetting("Blocks", "Comma-separated block ids, e.g. diamond_ore,chest", "diamond_ore,deepslate_diamond_ore,ancient_debris", 200));
        private final NumSetting radius = add(new NumSetting("Radius", "Scan radius (blocks)", 16, 4, 32, 1));
        private final ColorSetting color = add(new ColorSetting("Colour", "Outline colour", 0x40FFB0));
        private final List<BlockPos> hits = new ArrayList<>();
        private int timer;
        private String parsedFrom = null;
        private final Set<Block> wanted = new HashSet<>();

        public Search() {
            super("Search", "Outlines blocks of the types you list, but only when they are in your direct line of sight (nothing is shown through walls).", Category.RENDER, Status.IMPLEMENTED);
        }

        @Override protected void onEnable() { timer = 0; hits.clear(); }
        @Override protected void onDisable() { hits.clear(); }

        private void parse() {
            String cur = blocks.get();
            if (cur.equals(parsedFrom)) return;
            parsedFrom = cur;
            wanted.clear();
            for (String s : cur.split(",")) {
                String t = s.trim().toLowerCase(java.util.Locale.ROOT);
                if (t.isEmpty()) continue;
                Identifier id = Identifier.tryParse(t.contains(":") ? t : "minecraft:" + t);
                if (id == null) continue;
                Registries.BLOCK.getOptionalValue(id).ifPresent(wanted::add);
            }
        }

        @Override protected void onTick() {
            if (timer-- > 0) return;
            timer = 20;
            parse();
            if (wanted.isEmpty()) { synchronized (hits) { hits.clear(); } return; }
            var w = mc.world;
            var p = player();
            Vec3d eye = p.getEyePos();
            BlockPos c = p.getBlockPos();
            int r = radius.intVal();
            List<BlockPos> found = new ArrayList<>();
            for (int dx = -r; dx <= r && found.size() < 128; dx++)
                for (int dy = -r; dy <= r && found.size() < 128; dy++)
                    for (int dz = -r; dz <= r && found.size() < 128; dz++) {
                        BlockPos pos = c.add(dx, dy, dz);
                        if (!wanted.contains(w.getBlockState(pos).getBlock())) continue;
                        var ray = w.raycast(new RaycastContext(eye, Vec3d.ofCenter(pos), RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, p));
                        if (ray.getType() == HitResult.Type.BLOCK && ray.getBlockPos().equals(pos)) found.add(pos);
                    }
            synchronized (hits) { hits.clear(); hits.addAll(found); }
        }

        @Override public void renderWorld(Render3D.Frame f) {
            int col = argb(0xD0, color.rgb());
            synchronized (hits) { for (BlockPos b : hits) f.outline(new Box(b).expand(0.002), col, 0.03); }
        }
    }

    // ------------------------------------------------------------------------------------------
    /**
     * Detached camera without mixins: a client-only armour-stand is installed as the camera entity.
     * Your real body is held in place (position restored every tick) and mouse look turns the camera.
     * Attacks/use still originate from your real body. Own worlds only (private-test, host-world scope).
     */
    public static final class Freecam extends Module implements Render3D.WorldRenderable {
        private final NumSetting speed = add(new NumSetting("Speed", "Camera speed (blocks per tick)", 0.8, 0.1, 3.0, 0.1));
        private ArmorStandEntity cam;
        private ClientWorld world;
        private Vec3d camPos, anchor;

        public Freecam() {
            super("Freecam", "Detaches the camera from your body: WASD / jump / sneak fly the camera, your body stays put. Own worlds only.", Category.RENDER, Status.PRIVATE_TEST);
        }

        @Override protected void onEnable() {
            var p = mc.player;
            if (p == null || mc.world == null) { setEnabled(false); return; }
            world = mc.world;
            anchor = p.getEntityPos();
            camPos = p.getEyePos();
            cam = new ArmorStandEntity(world, camPos.x, camPos.y, camPos.z);
            place(camPos);
            cam.setYaw(p.getYaw());
            cam.setPitch(p.getPitch());
            mc.setCameraEntity(cam);
        }

        private void place(Vec3d eye) {
            double feetY = eye.y - cam.getEyeHeight(cam.getPose());
            cam.lastRenderX = cam.getX(); cam.lastRenderY = cam.getY(); cam.lastRenderZ = cam.getZ();
            cam.setPosition(eye.x, feetY, eye.z);
        }

        @Override protected void onDisable() {
            if (mc.player != null && mc.getCameraEntity() == cam) mc.setCameraEntity(mc.player);
            cam = null; world = null;
        }

        @Override protected void onTick() {
            var p = mc.player;
            if (cam == null || mc.world != world) { setEnabled(false); return; }
            // hold the real body still
            p.setPosition(anchor.x, anchor.y, anchor.z);
            p.setVelocity(Vec3d.ZERO);
            double yaw = Math.toRadians(p.getYaw());
            Vec3d fwd = new Vec3d(-Math.sin(yaw), 0, Math.cos(yaw)), right = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
            Vec3d d = Vec3d.ZERO;
            if (mc.currentScreen == null) {
                if (mc.options.forwardKey.isPressed()) d = d.add(fwd);
                if (mc.options.backKey.isPressed()) d = d.subtract(fwd);
                if (mc.options.rightKey.isPressed()) d = d.add(right);
                if (mc.options.leftKey.isPressed()) d = d.subtract(right);
                if (mc.options.jumpKey.isPressed()) d = d.add(0, 1, 0);
                if (mc.options.sneakKey.isPressed()) d = d.subtract(0, 1, 0);
            }
            if (d.lengthSquared() > 0) camPos = camPos.add(d.normalize().multiply(speed.val()));
            place(camPos);
        }

        /** Called every frame: keeps the camera rotation in step with mouse look without waiting for the next tick. */
        @Override public void renderWorld(Render3D.Frame f) {
            var p = mc.player;
            if (cam == null || p == null) return;
            cam.setYaw(p.getYaw()); cam.setPitch(p.getPitch());
            cam.lastYaw = p.getYaw(); cam.lastPitch = p.getPitch();
        }
    }

    // ------------------------------------------------------------------------------------------
    /** Removes selected visual effects on YOUR client only (weather, blindness, nausea, darkness). Server state is untouched. */
    public static final class NoRender extends Module {
        private final BoolSetting weather = add(new BoolSetting("Weather", "Hide rain and thunder visuals", true));
        private final BoolSetting blind = add(new BoolSetting("Blindness", "Remove the client-side blindness effect visuals", true));
        private final BoolSetting nausea = add(new BoolSetting("Nausea", "Remove the client-side nausea warp", true));
        private final BoolSetting dark = add(new BoolSetting("Darkness", "Remove the client-side darkness pulse", true));

        public NoRender() {
            super("NoRender", "Hides rain/thunder and the blindness, nausea and darkness screen effects client-side. Own worlds only (it would otherwise be a combat advantage).", Category.RENDER, Status.PRIVATE_TEST);
        }

        @Override protected void onTick() {
            var p = player();
            if (weather.on()) { mc.world.setRainGradient(0f); mc.world.setThunderGradient(0f); }
            if (blind.on()) p.removeStatusEffect(StatusEffects.BLINDNESS);
            if (nausea.on()) p.removeStatusEffect(StatusEffects.NAUSEA);
            if (dark.on()) p.removeStatusEffect(StatusEffects.DARKNESS);
        }
    }
}
