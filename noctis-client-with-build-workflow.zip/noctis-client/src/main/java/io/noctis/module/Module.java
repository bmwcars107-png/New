package io.noctis.module;

import io.noctis.NoctisClient;
import io.noctis.config.ConfigManager;
import io.noctis.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * Base class for all modules. Rendering, input and persistence live elsewhere:
 * a module only owns state, settings and game logic. Modules never register their own
 * Fabric event listeners (those cannot be removed); ModuleManager fans events out to enabled
 * modules only, which makes duplicate listeners and listener leaks impossible.
 */
public abstract class Module {
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    public final String name, description;
    public final Category category;
    public final Status status;
    public String group = "";
    public boolean defaultEnabled = false;
    public int defaultKey = -1;
    /** Where a PRIVATE_TEST module may run. SOLO_ONLY: only alone in your world. HOST_WORLD: also in your own world while LAN guests are online (never on remote servers). */
    public enum Scope { SOLO_ONLY, HOST_WORLD }
    public Scope scope = Scope.SOLO_ONLY;
    /** Action modules run once when toggled and switch themselves off again. */
    public boolean action = false;

    public final List<Setting<?>> settings = new ArrayList<>();
    public final List<String> conflicts = new ArrayList<>();

    private boolean enabled;
    private int key = -1;
    private int errors;
    public String lastError = "";
    public String notice = "";
    public float anim; // GUI toggle animation state

    protected Module(String name, String description, Category category, Status status) {
        this.name = name; this.description = description; this.category = category; this.status = status;
    }

    protected <S extends Setting<?>> S add(S s) { settings.add(s); return s; }

    // --- lifecycle hooks -------------------------------------------------------------------
    protected void onEnable() {}
    protected void onDisable() {}
    protected void onTick() {}

    // --- state -------------------------------------------------------------------------------
    public boolean isEnabled() { return enabled; }
    public int key() { return key; }
    public void setKey(int k) { this.key = (k >= 32 && k <= 348) ? k : -1; ConfigManager.markDirty(); }
    public boolean persistsEnabled() { return !action; }

    /** True only for an integrated-server world in which the local player is the only one online. */
    protected boolean aloneInSingleplayer() { return io.noctis.WorldContext.current() == io.noctis.WorldContext.Kind.SOLO; }

    /** Returns null when the module may run, otherwise a human readable reason. */
    public String blockedReason() {
        return switch (status) {
            case PLANNED -> "Not implemented in this build.";
            case BLOCKED -> "Not provided by design (combat automation, hit registration, hidden information or server-rule bypass).";
            case PRIVATE_TEST -> privateTestReason();
            default -> null;
        };
    }

    private String privateTestReason() {
        var k = io.noctis.WorldContext.current();
        return switch (k) {
            case NONE, SOLO -> null;
            case LAN_HOST -> scope == Scope.HOST_WORLD ? null
                    : "Solo-only: this module can affect other players, so it is off while friends are in your LAN world.";
            case REMOTE -> "Private-test only: refuses to run on a remote server (a friend's LAN world you joined counts as remote).";
        };
    }

    /** Combat helper: in a LAN world with guests, other players are never valid targets. */
    protected boolean mayTarget(net.minecraft.entity.Entity e) {
        if (!(e instanceof net.minecraft.entity.player.PlayerEntity)) return true;
        return io.noctis.WorldContext.current() == io.noctis.WorldContext.Kind.SOLO;
    }

    public boolean toggle() { return setEnabled(!enabled); }

    public boolean setEnabled(boolean on) {
        if (on == enabled) return true;
        if (on) {
            String reason = blockedReason();
            if (reason != null) { notice = reason; return false; }
            for (String c : conflicts) {
                Module o = ModuleManager.get(c);
                if (o != null && o.enabled) o.setEnabled(false);
            }
            enabled = true;
            errors = 0;
            lastError = "";
            try { onEnable(); } catch (Throwable t) { fail("enable", t); return false; }
        } else {
            enabled = false;
            try { onDisable(); } catch (Throwable t) { NoctisClient.LOG.error("{} failed in onDisable", name, t); }
        }
        if (!action) ConfigManager.markDirty();
        return true;
    }

    /** Called by ModuleManager once per client tick while enabled. One broken module cannot break the rest. */
    final void safeTick() {
        try {
            onTick();
        } catch (Throwable t) {
            if (++errors >= 3) fail("tick", t);
            else NoctisClient.LOG.warn("{} tick error {}/3: {}", name, errors, t.toString());
        }
    }

    private void fail(String where, Throwable t) {
        NoctisClient.LOG.error("{} failed during {}; disabling it", name, where, t);
        lastError = where + ": " + t.getClass().getSimpleName();
        notice = "Disabled after error (" + lastError + ")";
        enabled = false;
        try { onDisable(); } catch (Throwable ignored) { }
    }

    /** Drop transient state (used by SelfDestruct). */
    public void clearTransient() { lastError = ""; notice = ""; anim = 0; }

    public void resetToDefaults() { for (Setting<?> s : settings) s.reset(); key = defaultKey; }

    // --- helpers ----------------------------------------------------------------------------
    protected ClientPlayerEntity player() { return mc.player; }
    protected boolean inGame() { return mc.player != null && mc.world != null && mc.interactionManager != null; }
}
