package io.noctis.module.impl;

import io.noctis.module.*;
import io.noctis.module.Module;
import io.noctis.setting.BoolSetting;
import io.noctis.setting.NumSetting;
import io.noctis.setting.StrSetting;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

import static io.noctis.module.impl.Modules.unavailable;

public final class MacroModules {
    private MacroModules() {}

    static void register() {
        ModuleManager.register(new ChestStealer());
        ModuleManager.register(new KeyPearlMacro());
        ModuleManager.register(new KeyCharge());
        ModuleManager.register(new Tunneler());
        for (int i = 1; i <= 3; i++) ModuleManager.register(new DonutCommand(i));

        Category c = Category.MACROS;
        unavailable(c, Status.BLOCKED, "DiveBomb", "Elytra dive-and-strike macro.", "Reviewed: an automated elytra-dive-and-mace attack is combat automation; the manual building blocks (ElytraSwap, MaceSwap, AutoMace in your own world) already exist. Deliberately unavailable.");
}

    // ------------------------------------------------------------------------------------------
    public static final class ChestStealer extends Module {
        private final NumSetting delay = add(new NumSetting("Delay", "Ticks between moves", 2, 0, 10, 1));
        private final BoolSetting close = add(new BoolSetting("Close when empty", "Close the container after the last item", true));
        private int wait;
        public ChestStealer() { super("ChestStealer", "Shift-clicks every item out of an open chest-style container. Singleplayer test worlds only.", Category.MACROS, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            if (!(mc.currentScreen instanceof GenericContainerScreen gs)) { wait = 0; return; }
            if (wait-- > 0) return;
            GenericContainerScreenHandler h = gs.getScreenHandler();
            int n = h.getRows() * 9;
            for (int i = 0; i < n; i++) {
                if (h.getSlot(i).hasStack()) {
                    mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, player());
                    wait = delay.intVal();
                    return;
                }
            }
            if (close.on()) player().closeHandledScreen();
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class KeyPearlMacro extends ActionModule {
        private final BoolSetting back = add(new BoolSetting("Switch back", "Return to your previous slot", true));
        public KeyPearlMacro() { super("KeyPearlMacro", "Throws an ender pearl from your hotbar when triggered (bind a key). User-triggered shortcut.", Category.MACROS, Status.IMPLEMENTED); }
        @Override protected void run() {
            if (!inGame() || mc.currentScreen != null) return;
            int slot = Inv.hotbar(s -> s.isOf(Items.ENDER_PEARL));
            if (slot < 0) { Inv.say("KeyPearlMacro: no ender pearl in your hotbar."); return; }
            int prev = Inv.selected();
            Inv.select(slot);
            mc.interactionManager.interactItem(player(), Hand.MAIN_HAND);
            if (back.on()) Inv.select(prev);
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class KeyCharge extends ActionModule {
        private final BoolSetting back = add(new BoolSetting("Switch back", "Return to your previous slot", true));
        public KeyCharge() { super("KeyCharge", "Uses a wind charge from your hotbar when triggered (bind a key). User-triggered shortcut.", Category.MACROS, Status.IMPLEMENTED); }
        @Override protected void run() {
            if (!inGame() || mc.currentScreen != null) return;
            int slot = Inv.hotbar(s -> s.isOf(Items.WIND_CHARGE));
            if (slot < 0) { Inv.say("KeyCharge: no wind charge in your hotbar."); return; }
            int prev = Inv.selected();
            Inv.select(slot);
            mc.interactionManager.interactItem(player(), Hand.MAIN_HAND);
            if (back.on()) Inv.select(prev);
        }
    }

    // ------------------------------------------------------------------------------------------
    /** Holds forward + attack to dig a straight tunnel; stops itself on low health, liquids or when a screen opens. */
    public static final class Tunneler extends Module {
        private final NumSetting minHealth = add(new NumSetting("Stop below", "Stop when health (half-hearts) is at or below this", 6, 1, 20, 1));
        public Tunneler() { super("Tunneler", "Holds forward and attack so you dig a straight tunnel. Stops on low health or when a liquid is ahead. Singleplayer test worlds only.", Category.MACROS, Status.PRIVATE_TEST); conflicts.add("AutoWalk"); }
        @Override protected void onTick() {
            if (mc.currentScreen != null) { release(); return; }
            var p = player();
            if (p.getHealth() <= minHealth.val()) { Inv.say("Tunneler: stopped (low health)."); setEnabled(false); return; }
            if (mc.crosshairTarget instanceof net.minecraft.util.hit.BlockHitResult hit && hit.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK
                    && !mc.world.getFluidState(hit.getBlockPos()).isEmpty()) {
                Inv.say("Tunneler: stopped (liquid ahead)."); setEnabled(false); return;
            }
            mc.options.forwardKey.setPressed(true);
            mc.options.attackKey.setPressed(true);
        }
        private void release() { Inv.restoreKey(mc.options.forwardKey); Inv.restoreKey(mc.options.attackKey); }
        @Override protected void onDisable() { if (mc.player != null) release(); }
    }

    // ------------------------------------------------------------------------------------------
    /**
     * Server-specific command macros. Nothing about any server is assumed: the command text and the
     * server-address filter are entirely user-configured. It only sends the chat command you typed.
     */
    public static final class DonutCommand extends ActionModule {
        private final StrSetting command;
        private final StrSetting serverMatch;
        private long lastRun;
        private final BoolSetting requireServer = add(new BoolSetting("Only on matching server", "Refuse to run unless the server address contains the filter below", true));

        public DonutCommand(int i) {
            super("DonutCommand" + i, "User-defined chat command macro #" + i + " for a server you configure. Empty by default; no server behaviour is assumed.", Category.MACROS, Status.IMPLEMENTED);
            group = "Donut";
            command = add(new StrSetting("Command", "Command without the leading slash, e.g. shop", "", 128));
            serverMatch = add(new StrSetting("Server contains", "Part of the server address this macro is allowed on (e.g. donutsmp.net)", "", 64));
        }

        @Override protected void run() {
            if (!inGame() || mc.getNetworkHandler() == null) return;
            String cmd = command.get().trim();
            if (cmd.startsWith("/")) cmd = cmd.substring(1);
            if (cmd.isEmpty()) { Inv.say(name + ": set a command in the module settings first."); return; }
            if (MiscModules.isSensitive(cmd)) { Inv.say(name + ": refusing to send an authentication-style command (login/register/password). Macro settings are stored in plain text."); return; }
            long now = System.currentTimeMillis();
            if (now - lastRun < 1000) { Inv.say(name + ": wait a second between runs."); return; }
            lastRun = now;
            if (requireServer.on()) {
                String f = serverMatch.get().trim().toLowerCase();
                var e = mc.getCurrentServerEntry();
                if (f.isEmpty() || e == null || !e.address.toLowerCase().contains(f)) {
                    Inv.say(name + ": not on a matching server (set 'Server contains').");
                    return;
                }
            }
            mc.getNetworkHandler().sendChatCommand(cmd);
        }
    }
}
