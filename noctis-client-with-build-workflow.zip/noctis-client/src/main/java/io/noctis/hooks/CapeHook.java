package io.noctis.hooks;

import io.noctis.module.impl.ExtraModules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.util.AssetInfo;
import net.minecraft.util.Identifier;

/** Called by CapeFeatureRendererMixin. Only ever touches the render state of the local player. */
public final class CapeHook {
    private CapeHook() {}

    public static volatile long calls;

    public static void apply(PlayerEntityRenderState state) {
        calls++;
        ExtraModules.Capes cm = ExtraModules.CAPES;
        if (cm == null || !cm.isEnabled()) return;
        var p = MinecraftClient.getInstance().player;
        if (p == null || state == null || state.id != p.getId()) return;
        Identifier id = cm.textureId();
        SkinTextures st = state.skinTextures;
        if (id == null || st == null) return;
        // texturePath is the registered texture id for both bundled (resource) and dynamic (config folder) capes.
        AssetInfo.TextureAssetInfo cape = new AssetInfo.TextureAssetInfo(id, id);
        state.skinTextures = new SkinTextures(st.body(), cape, cm.matchElytra() ? cape : st.elytra(), st.model(), st.secure());
    }
}
