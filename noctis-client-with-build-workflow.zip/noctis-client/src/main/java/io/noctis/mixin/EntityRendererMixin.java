package io.noctis.mixin;

import io.noctis.hooks.NametagHook;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Nametags hook: rewrites EntityRenderState.displayName after vanilla filled it (verified Yarn 1.21.11 fields). */
@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin {
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/Entity;Lnet/minecraft/client/render/entity/state/EntityRenderState;F)V",
            at = @At("TAIL"))
    private void noctis$nametag(Entity entity, EntityRenderState state, float tickProgress, CallbackInfo ci) {
        NametagHook.apply(entity, state);
    }
}
