package io.noctis.mixin;

import io.noctis.hooks.MoveFixHook;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.util.math.Vec2f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** MoveFix hook: rotates the movement vector right after the keyboard filled it (Input.movementVector is protected). */
@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin extends Input {
    @Inject(method = "tick()V", at = @At("TAIL"))
    private void noctis$moveFix(CallbackInfo ci) {
        Vec2f v = this.movementVector;
        if (v != null) this.movementVector = MoveFixHook.rotate(v);
    }
}
