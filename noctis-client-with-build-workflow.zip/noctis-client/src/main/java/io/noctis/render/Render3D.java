package io.noctis.render;

import io.noctis.NoctisClient;
import io.noctis.module.Module;
import io.noctis.module.ModuleManager;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * World-space drawing. Uses exactly the pattern of Fabric API's own WorldRenderEventsTests for 1.21.11:
 * BEFORE_TRANSLUCENT, push + translate(-camera), getBuffer(debug filled box layer), position+colour vertices.
 * Only filled quads are used (lines are drawn as camera-facing ribbons), so no normals / line widths are needed.
 * Nothing here has been run in a client yet.
 */
public final class Render3D {
    private Render3D() {}

    /** Implemented by modules that draw in the world. Called only while the module is enabled. */
    public interface WorldRenderable { void renderWorld(Frame f); }

    private static boolean failed;

    public static void register() {
        WorldRenderEvents.BEFORE_TRANSLUCENT.register(Render3D::draw);
    }

    private static void draw(WorldRenderContext ctx) {
        if (failed) return;
        List<WorldRenderable> active = null;
        for (Module m : ModuleManager.all()) {
            if (m.isEnabled() && m instanceof WorldRenderable w) {
                if (active == null) active = new ArrayList<>();
                active.add(w);
            }
        }
        if (active == null) return;
        try {
            Vec3d cam = ctx.worldState().cameraRenderState.pos;
            var matrices = ctx.matrices();
            matrices.push();
            matrices.translate(-cam.x, -cam.y, -cam.z);
            Frame f = new Frame(cam, matrices.peek().getPositionMatrix(), ctx.consumers().getBuffer(RenderLayers.DEBUG_FILLED_BOX));
            for (WorldRenderable w : active) {
                try { w.renderWorld(f); } catch (Throwable t) {
                    NoctisClient.LOG.warn("World render error in {}: {}", w.getClass().getSimpleName(), t.toString());
                }
            }
            matrices.pop();
        } catch (Throwable t) {
            failed = true; // never spam or crash the render thread
            NoctisClient.LOG.error("Noctis world rendering disabled after an error", t);
        }
    }

    public static final class Frame {
        public final Vec3d cam;
        private final Matrix4f m;
        private final VertexConsumer vc;

        Frame(Vec3d cam, Matrix4f m, VertexConsumer vc) { this.cam = cam; this.m = m; this.vc = vc; }

        private void v(double x, double y, double z, int argb) { vc.vertex(m, (float) x, (float) y, (float) z).color(argb); }

        /** Quad emitted with both windings so it shows regardless of face culling. */
        public void quad(Vec3d a, Vec3d b, Vec3d c, Vec3d d, int argb) {
            v(a.x, a.y, a.z, argb); v(b.x, b.y, b.z, argb); v(c.x, c.y, c.z, argb); v(d.x, d.y, d.z, argb);
            v(d.x, d.y, d.z, argb); v(c.x, c.y, c.z, argb); v(b.x, b.y, b.z, argb); v(a.x, a.y, a.z, argb);
        }

        /** A line drawn as a ribbon of the given width (blocks) that faces the camera. */
        public void line(Vec3d a, Vec3d b, int argb, double width) {
            Vec3d dir = b.subtract(a);
            if (dir.lengthSquared() < 1.0E-8) return;
            Vec3d toCam = a.subtract(cam);
            Vec3d side = dir.crossProduct(toCam);
            if (side.lengthSquared() < 1.0E-10) side = dir.crossProduct(new Vec3d(0, 1, 0));
            if (side.lengthSquared() < 1.0E-10) side = dir.crossProduct(new Vec3d(1, 0, 0));
            side = side.normalize().multiply(width / 2.0);
            quad(a.add(side), a.subtract(side), b.subtract(side), b.add(side), argb);
        }

        public void fillBox(Box bx, int argb) {
            Vec3d a = new Vec3d(bx.minX, bx.minY, bx.minZ), b = new Vec3d(bx.maxX, bx.minY, bx.minZ);
            Vec3d c = new Vec3d(bx.maxX, bx.minY, bx.maxZ), d = new Vec3d(bx.minX, bx.minY, bx.maxZ);
            Vec3d e = new Vec3d(bx.minX, bx.maxY, bx.minZ), f = new Vec3d(bx.maxX, bx.maxY, bx.minZ);
            Vec3d g = new Vec3d(bx.maxX, bx.maxY, bx.maxZ), h = new Vec3d(bx.minX, bx.maxY, bx.maxZ);
            quad(a, b, c, d, argb); quad(e, f, g, h, argb);
            quad(a, b, f, e, argb); quad(d, c, g, h, argb);
            quad(a, d, h, e, argb); quad(b, c, g, f, argb);
        }

        public void outline(Box bx, int argb, double w) {
            Vec3d[] p = {
                new Vec3d(bx.minX, bx.minY, bx.minZ), new Vec3d(bx.maxX, bx.minY, bx.minZ),
                new Vec3d(bx.maxX, bx.minY, bx.maxZ), new Vec3d(bx.minX, bx.minY, bx.maxZ),
                new Vec3d(bx.minX, bx.maxY, bx.minZ), new Vec3d(bx.maxX, bx.maxY, bx.minZ),
                new Vec3d(bx.maxX, bx.maxY, bx.maxZ), new Vec3d(bx.minX, bx.maxY, bx.maxZ)};
            int[][] e = {{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
            for (int[] k : e) line(p[k[0]], p[k[1]], argb, w);
        }
    }
}
