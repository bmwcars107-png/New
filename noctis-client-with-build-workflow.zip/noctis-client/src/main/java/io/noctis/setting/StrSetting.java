package io.noctis.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class StrSetting extends Setting<String> {
    public final int maxLen;

    public StrSetting(String name, String description, String def, int maxLen) {
        super(name, description, def);
        this.maxLen = maxLen;
    }

    @Override protected String sanitize(String v) {
        if (v == null) return def;
        StringBuilder sb = new StringBuilder();
        for (char c : v.toCharArray()) if (c >= 32 && c != 127 && sb.length() < maxLen) sb.append(c);
        return sb.toString();
    }

    @Override public JsonElement toJson() { return new JsonPrimitive(value); }

    @Override public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive() || !e.getAsJsonPrimitive().isString())
            throw new IllegalArgumentException("expected string");
        if (e.getAsString().length() > maxLen) throw new IllegalArgumentException("too long");
        set(e.getAsString());
    }
}
