package io.noctis.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.List;

public final class ModeSetting extends Setting<String> {
    public final List<String> options;

    public ModeSetting(String name, String description, String def, String... options) {
        super(name, description, def);
        this.options = List.of(options);
        if (!this.options.contains(def)) throw new IllegalArgumentException("default not in options: " + name);
    }

    @Override protected String sanitize(String v) { return v != null && options.contains(v) ? v : def; }

    @Override public JsonElement toJson() { return new JsonPrimitive(value); }

    @Override public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive() || !e.getAsJsonPrimitive().isString())
            throw new IllegalArgumentException("expected string");
        String s = e.getAsString();
        if (!options.contains(s)) throw new IllegalArgumentException("unknown option '" + s + "'");
        set(s);
    }

    public boolean is(String o) { return value.equals(o); }
    public int index() { return options.indexOf(value); }
    public void cycle(int dir) { set(options.get(Math.floorMod(index() + dir, options.size()))); }
}
