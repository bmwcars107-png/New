package io.noctis.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class NumSetting extends Setting<Double> {
    public final double min, max, step;

    public NumSetting(String name, String description, double def, double min, double max, double step) {
        super(name, description, def);
        this.min = min; this.max = max; this.step = step;
        this.value = sanitize(def);
    }

    @Override protected Double sanitize(Double v) {
        double x = (v == null || v.isNaN() || v.isInfinite()) ? def : v;
        x = Math.max(min, Math.min(max, x));
        if (step > 0) x = min + Math.round((x - min) / step) * step;
        x = Math.max(min, Math.min(max, x));
        return Math.round(x * 10000.0) / 10000.0;
    }

    @Override public JsonElement toJson() { return new JsonPrimitive(value); }

    @Override public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive() || !e.getAsJsonPrimitive().isNumber())
            throw new IllegalArgumentException("expected number");
        double d = e.getAsDouble();
        if (Double.isNaN(d) || Double.isInfinite(d) || d < min || d > max)
            throw new IllegalArgumentException("out of range " + min + ".." + max);
        set(d);
    }

    public double val() { return value; }
    public int intVal() { return (int) Math.round(value); }
    public float floatVal() { return value.floatValue(); }
    public boolean isInteger() { return step >= 1.0 && step == Math.floor(step); }
    public double fraction() { return max == min ? 0 : (value - min) / (max - min); }
}
