package io.noctis.setting;

import com.google.gson.JsonElement;
import io.noctis.config.ConfigManager;

import java.util.function.BooleanSupplier;

/** Base class for every configurable value. Values are validated on every write. */
public abstract class Setting<T> {
    public final String name;
    public final String description;
    protected T value;
    protected final T def;
    private BooleanSupplier visibleWhen = () -> true;
    private boolean hidden;

    protected Setting(String name, String description, T def) {
        this.name = name;
        this.description = description;
        this.def = def;
        this.value = def;
    }

    public T get() { return value; }

    public void set(T v) {
        T clean = sanitize(v);
        if (!clean.equals(value)) {
            value = clean;
            ConfigManager.markDirty();
        }
    }

    public void reset() { value = def; }

    /** Clamp / normalise a value. Must never throw for in-range input. */
    protected abstract T sanitize(T v);

    public abstract JsonElement toJson();

    /** Strict parse used when loading config. Throws IllegalArgumentException for bad input. */
    public abstract void fromJson(JsonElement e);

    public Setting<T> showIf(BooleanSupplier s) { this.visibleWhen = s; return this; }

    /** Hidden settings are persisted but never rendered in the ClickGUI. */
    public Setting<T> hide() { this.hidden = true; return this; }

    public boolean visible() { return !hidden && visibleWhen.getAsBoolean(); }
}
