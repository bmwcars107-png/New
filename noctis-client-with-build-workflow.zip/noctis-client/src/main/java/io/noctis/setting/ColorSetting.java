package io.noctis.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.regex.Pattern;

/** Opaque ARGB colour, serialised as "#RRGGBB". */
public final class ColorSetting extends Setting<Integer> {
    private static final Pattern HEX = Pattern.compile("#[0-9a-fA-F]{6}");

    public ColorSetting(String name, String description, int rgb) { super(name, description, 0xFF000000 | rgb); }

    @Override protected Integer sanitize(Integer v) { return v == null ? def : (0xFF000000 | v); }

    @Override public JsonElement toJson() { return new JsonPrimitive(String.format("#%06X", value & 0xFFFFFF)); }

    @Override public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive() || !e.getAsJsonPrimitive().isString())
            throw new IllegalArgumentException("expected \"#RRGGBB\"");
        String s = e.getAsString();
        if (!HEX.matcher(s).matches()) throw new IllegalArgumentException("bad colour '" + s + "'");
        set(Integer.parseInt(s.substring(1), 16));
    }

    public int rgb() { return value; }
}
