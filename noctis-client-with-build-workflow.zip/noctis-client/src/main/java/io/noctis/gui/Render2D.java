package io.noctis.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * All raw drawing helpers. Anything version-sensitive (matrix stack, text drawing) is isolated here
 * so a Minecraft API change only needs fixing in this one file.
 */
public final class Render2D {
    private Render2D() {}

    public static TextRenderer tr() { return MinecraftClient.getInstance().textRenderer; }
    public static int tw(String s) { return tr().getWidth(s); }

    public static int a(int argb, float alpha) {
        int al = Math.max(0, Math.min(255, (int) ((argb >>> 24) * alpha)));
        return (al << 24) | (argb & 0xFFFFFF);
    }

    public static int mix(int c1, int c2, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int al = (int) (((c1 >>> 24) & 255) + (((c2 >>> 24) & 255) - ((c1 >>> 24) & 255)) * t);
        int r = (int) (((c1 >> 16) & 255) + (((c2 >> 16) & 255) - ((c1 >> 16) & 255)) * t);
        int g = (int) (((c1 >> 8) & 255) + (((c2 >> 8) & 255) - ((c1 >> 8) & 255)) * t);
        int b = (int) ((c1 & 255) + ((c2 & 255) - (c1 & 255)) * t);
        return (al << 24) | (r << 16) | (g << 8) | b;
    }

    public static void text(DrawContext c, String s, int x, int y, int color) { c.drawText(tr(), s, x, y, color, false); }
    public static void shadow(DrawContext c, String s, int x, int y, int color) { c.drawText(tr(), s, x, y, color, true); }
    public static void centered(DrawContext c, String s, int cx, int y, int color) { text(c, s, cx - tw(s) / 2, y, color); }

    /** Rounded rectangle built from non-overlapping row strips (safe with translucent colours). */
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) { c.fill(x, y, x + w, y + h, color); return; }
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
        c.fill(x, y + r, x + w, y + h - r, color);
    }

    public static void hGradient(DrawContext c, int x, int y, int w, int h, int c1, int c2) {
        int step = 3;
        for (int i = 0; i < w; i += step) c.fill(x + i, y, x + Math.min(w, i + step), y + h, mix(c1, c2, i / (float) Math.max(1, w)));
    }

    public static void vGradient(DrawContext c, int x, int y, int w, int h, int c1, int c2) { c.fillGradient(x, y, x + w, y + h, c1, c2); }

    public static void outline(DrawContext c, int x, int y, int w, int h, int color) {
        c.fill(x, y, x + w, y + 1, color);
        c.fill(x, y + h - 1, x + w, y + h, color);
        c.fill(x, y + 1, x + 1, y + h - 1, color);
        c.fill(x + w - 1, y + 1, x + w, y + h - 1, color);
    }

    public static void push(DrawContext c, float x, float y, float scale) {
        c.getMatrices().pushMatrix();
        c.getMatrices().translate(x, y);
        c.getMatrices().scale(scale, scale);
    }

    public static void pop(DrawContext c) { c.getMatrices().popMatrix(); }

    public static String trim(String s, int width) { return tr().trimToWidth(s, width); }

    /** Original crescent-and-star mark, drawn procedurally (no texture needed). */
    public static void logo(DrawContext c, int cx, int cy, int R, int top, int bottom, float alpha) {
        for (int dy = -R; dy <= R; dy++) {
            double hw = Math.sqrt(R * R - dy * (double) dy);
            double ix = R * 0.55, ir = R * 0.82;
            double ihw = Math.abs(dy) < ir ? Math.sqrt(ir * ir - dy * (double) dy) : -1;
            int left = (int) Math.round(cx - hw);
            int right = (int) Math.round(cx + hw);
            int cut = ihw < 0 ? right : (int) Math.round(cx + ix - ihw);
            int col = a(mix(top, bottom, (dy + R) / (2f * R)), alpha);
            if (cut > left) c.fill(left, cy + dy, Math.min(cut, right), cy + dy + 1, col);
        }
        int sx = cx + R / 2 + 1, sy = cy - R / 3;
        c.fill(sx - 1, sy, sx + 2, sy + 1, a(0xFFE9ECF3, alpha));
        c.fill(sx, sy - 1, sx + 1, sy + 2, a(0xFFE9ECF3, alpha));
    }

    private static final String[][] ICONS = {
            {"......#", ".....##", "....##.", "#..##..", ".###...", "..#....", ".#.#..."},             // combat
            {"...#...", "..###..", ".#.#.#.", "...#...", "...#...", "...#...", "...#..."},             // movement
            {"..###..", ".#####.", ".#####.", "..###..", ".#####.", "#######", "#######"},             // player
            {"....##.", "...##..", "..##...", ".#####.", "...##..", "..##...", ".##...."},             // macros
            {".......", "..###..", ".#####.", "###.###", ".#####.", "..###..", "......."},             // render
            {"#######", "#.....#", "#.###.#", "#.....#", "#.##..#", "#.....#", "#######"},             // hud
            {"#.#.#.#", ".......", "#.#.#.#", ".......", "#.#.#.#", ".......", "#.#.#.#"},             // misc
            {"###....", "#######", "#.....#", "#.....#", "#.....#", "#.....#", "#######"},             // profiles
    };

    public static void icon(DrawContext c, int index, int x, int y, int px, int color) {
        String[] rows = ICONS[index];
        for (int r = 0; r < 7; r++)
            for (int k = 0; k < 7; k++)
                if (rows[r].charAt(k) == '#') c.fill(x + k * px, y + r * px, x + k * px + px, y + r * px + px, color);
    }
}
