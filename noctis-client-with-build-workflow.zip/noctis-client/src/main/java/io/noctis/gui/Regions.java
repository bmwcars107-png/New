package io.noctis.gui;

import java.util.ArrayList;
import java.util.List;

/** Per-frame hit regions for the immediate-mode GUI. Later regions sit on top of earlier ones. */
final class Regions {
    interface Press { void on(double x, double y, int button); }
    interface Drag { void on(double x, double y); }

    static final class R {
        int x, y, w, h;
        Press press;
        Drag drag;
        boolean has(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private final List<R> list = new ArrayList<>();
    private R active;
    private boolean clip;
    private int cx0, cy0, cx1, cy1;

    void clear() { list.clear(); }
    void setClip(int x0, int y0, int x1, int y1) { clip = true; cx0 = x0; cy0 = y0; cx1 = x1; cy1 = y1; }
    void clearClip() { clip = false; }

    boolean visible(double mx, double my) { return !clip || (mx >= cx0 && mx < cx1 && my >= cy0 && my < cy1); }

    R add(int x, int y, int w, int h, Press p, Drag d) {
        int x0 = x, y0 = y, x1 = x + w, y1 = y + h;
        if (clip) { x0 = Math.max(x0, cx0); y0 = Math.max(y0, cy0); x1 = Math.min(x1, cx1); y1 = Math.min(y1, cy1); }
        if (x1 <= x0 || y1 <= y0) return null;
        R r = new R();
        r.x = x0; r.y = y0; r.w = x1 - x0; r.h = y1 - y0; r.press = p; r.drag = d;
        list.add(r);
        return r;
    }

    boolean press(double mx, double my, int button) {
        for (int i = list.size() - 1; i >= 0; i--) {
            R r = list.get(i);
            if (r.has(mx, my)) {
                if (r.press != null) r.press.on(mx, my, button);
                active = r.drag != null && button == 0 ? r : null;
                return true;
            }
        }
        active = null;
        return false;
    }

    boolean drag(double mx, double my) {
        if (active == null) return false;
        active.drag.on(mx, my);
        return true;
    }

    void release() { active = null; }
}
