package io.noctis.gui;

import io.noctis.config.ConfigManager;
import io.noctis.hud.HudManager;
import io.noctis.hud.HudModule;
import io.noctis.module.Module;
import io.noctis.module.ModuleManager;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Drag-and-drop HUD editor with live preview: the real elements are drawn exactly where they will appear in game. */
public final class HudEditorScreen extends Screen {
    private final Screen parent;
    private final Regions rg = new Regions();
    private HudModule selected;
    private int offX, offY;

    public HudEditorScreen(Screen parent) {
        super(Text.literal("HUD Editor"));
        this.parent = parent;
    }

    @Override protected void init() { HudManager.preview = true; }
    @Override public void removed() { HudManager.preview = false; ConfigManager.markDirty(); }
    @Override public boolean shouldPause() { return false; }

    private List<HudModule> hud(boolean enabled) {
        List<HudModule> out = new ArrayList<>();
        for (Module m : ModuleManager.all()) if (m instanceof HudModule h && h.isEnabled() == enabled) out.add(h);
        return out;
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        rg.clear();
        c.fill(0, 0, width, height, Render2D.a(0xFF05050A, 0.55f));
        // subtle guide lines
        c.fill(width / 2, 0, width / 2 + 1, height, Render2D.a(Theme.primary(), 0.12f));
        c.fill(0, height / 2, width, height / 2 + 1, Render2D.a(Theme.primary(), 0.12f));

        // elements (added before UI so toolbar buttons sit on top)
        for (HudModule h : hud(true)) {
            HudManager.renderOne(c, h);
            int px = Math.min(h.x.intVal(), Math.max(0, width - h.sw())), py = Math.min(h.y.intVal(), Math.max(0, height - h.sh()));
            int w = Math.max(8, h.sw()), hh = Math.max(8, h.sh());
            boolean sel = h == selected;
            Render2D.outline(c, px - 1, py - 1, w + 2, hh + 2, sel ? Theme.primary() : Render2D.a(Theme.SILVER, 0.35f));
            if (sel) Render2D.text(c, h.name, px, py - 11, Theme.primary());
            rg.add(px, py, w, hh, (x, y, b) -> { selected = h; offX = (int) x - px; offY = (int) y - py; },
                    (x, y) -> move(h, (int) x - offX, (int) y - offY));
        }

        // disabled elements as chips along the top
        Render2D.text(c, "Add element:", 8, 8, Theme.DIM);
        int cx = 8 + Render2D.tw("Add element:") + 8, cy = 4;
        for (HudModule h : hud(false)) {
            int w = Render2D.tw("+ " + h.name) + 14;
            if (cx + w > width - 8) { cx = 8; cy += 20; }
            Ui.button(c, rg, cx, cy, w, 16, "+ " + h.name, mx, my, 1f, false, (x, y, b) -> { h.setEnabled(true); selected = h; });
            cx += w + 6;
        }

        drawToolbar(c, mx, my);
    }

    private void move(HudModule h, int nx, int ny) {
        int w = Math.max(1, h.sw()), hh = Math.max(1, h.sh());
        nx = Math.max(0, Math.min(width - w, nx));
        ny = Math.max(0, Math.min(height - hh, ny));
        int snap = 6;
        if (Math.abs(nx) < snap) nx = 0;
        if (Math.abs(nx + w - width) < snap) nx = width - w;
        if (Math.abs(nx + w / 2 - width / 2) < snap) nx = width / 2 - w / 2;
        if (Math.abs(ny) < snap) ny = 0;
        if (Math.abs(ny + hh - height) < snap) ny = height - hh;
        if (Math.abs(ny + hh / 2 - height / 2) < snap) ny = height / 2 - hh / 2;
        h.x.set((double) nx);
        h.y.set((double) ny);
    }

    private void drawToolbar(DrawContext c, int mx, int my) {
        int w = 470, h = 40, x = (width - w) / 2, y = height - h - 10;
        Render2D.rrect(c, x, y, w, h, 8, Render2D.a(Theme.BG, 0.95f));
        Render2D.hGradient(c, x + 8, y, w - 16, 2, Theme.primary(), Theme.secondary());
        String label = selected == null ? "Drag an element - click one to edit it" : selected.name;
        Render2D.text(c, Render2D.trim(label, 130), x + 12, y + 16, selected == null ? Theme.DIM : Theme.TEXT);
        if (selected != null) {
            HudModule s = selected;
            int bx = x + 150;
            Render2D.text(c, "Size", bx, y + 8, Theme.DIM);
            Ui.button(c, rg, bx, y + 18, 18, 16, "-", mx, my, 1f, false, (px, py, b) -> s.scale.set(s.scale.val() - 0.1));
            Ui.button(c, rg, bx + 20, y + 18, 18, 16, "+", mx, my, 1f, false, (px, py, b) -> s.scale.set(s.scale.val() + 0.1));
            bx += 52;
            Render2D.text(c, "Opacity", bx, y + 8, Theme.DIM);
            Ui.button(c, rg, bx, y + 18, 18, 16, "-", mx, my, 1f, false, (px, py, b) -> s.opacity.set(s.opacity.val() - 0.1));
            Ui.button(c, rg, bx + 20, y + 18, 18, 16, "+", mx, my, 1f, false, (px, py, b) -> s.opacity.set(s.opacity.val() + 0.1));
            bx += 52;
            Ui.button(c, rg, bx, y + 18, 50, 16, s.background.on() ? "Panel on" : "Panel off", mx, my, 1f, false, (px, py, b) -> s.background.toggle());
            bx += 54;
            Ui.button(c, rg, bx, y + 18, 40, 16, "Hide", mx, my, 1f, false, (px, py, b) -> { s.setEnabled(false); selected = null; });
        }
        Ui.button(c, rg, x + w - 52, y + 12, 42, 16, "Done", mx, my, 1f, true, (px, py, b) -> close());
    }

    @Override public void close() { if (client != null) client.setScreen(parent); }

    @Override public boolean mouseClicked(Click click, boolean doubled) {
        if (!rg.press(click.x(), click.y(), click.button())) selected = null;
        return true;
    }
    @Override public boolean mouseReleased(Click click) { rg.release(); return true; }
    @Override public boolean mouseDragged(Click click, double dx, double dy) { rg.drag(click.x(), click.y()); return true; }

    @Override public boolean mouseScrolled(double mx, double my, double h, double v) {
        if (selected != null) selected.scale.set(selected.scale.val() + Math.signum(v) * 0.05);
        return true;
    }

    @Override public boolean keyPressed(KeyInput input) {
        if (input.key() == 256) { close(); return true; }
        return true;
    }
}
