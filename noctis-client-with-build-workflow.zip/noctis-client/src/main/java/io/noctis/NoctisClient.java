package io.noctis;

import io.noctis.config.ConfigManager;
import io.noctis.hud.HudManager;
import io.noctis.module.ModuleManager;
import io.noctis.module.impl.MiscModules;
import io.noctis.module.impl.Modules;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class NoctisClient implements ClientModInitializer {
    public static final String ID = "noctis", NAME = "Noctis", VERSION = "1.0.0";
    public static final Logger LOG = LoggerFactory.getLogger(NAME);

    @Override
    public void onInitializeClient() {
        Modules.registerAll();
        io.noctis.render.Render3D.register();
        ConfigManager.init();

        // Exactly one listener per event, registered once. Modules never register listeners themselves.
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            ModuleManager.tick(mc);
            ConfigManager.autosaveTick();
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> ConfigManager.save());
        ClientPlayConnectionEvents.JOIN.register((handler, sender, mc) -> ConfigManager.onJoin(mc));
        ClientSendMessageEvents.COMMAND.register(MiscModules::logCommand);
        HudElementRegistry.addLast(Identifier.of(ID, "hud"), (ctx, tickCounter) -> HudManager.render(ctx));

        LOG.info("{} {} initialised with {} catalogue entries", NAME, VERSION, ModuleManager.all().size());
    }
}
