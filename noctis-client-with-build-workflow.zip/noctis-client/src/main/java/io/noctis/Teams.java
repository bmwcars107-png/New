package io.noctis;

import io.noctis.module.impl.MiscModules;

/** Small facade so other modules can ask "is this player on my friends list?". */
public final class Teams {
    private Teams() {}

    public static boolean isFriend(String playerName) {
        return MiscModules.TEAMS != null && MiscModules.TEAMS.isEnabled() && MiscModules.TEAMS.contains(playerName);
    }
}
