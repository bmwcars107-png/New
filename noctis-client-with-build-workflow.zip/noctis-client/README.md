# Noctis Client

An original Fabric client for **Minecraft Java 1.21.11** (Java 21): ClickGUI, HUD editor, validated config profiles and a module framework that reports an honest status for every catalogue entry.

> ## Read this first
> **This project has still never been compiled or launched.** The authoring sandbox has no network access (Maven, Gradle, Mojang and GitHub are all unreachable) and only a JRE, so `./gradlew build` could not be run and no JAR is included. All 82 modules are therefore *"implemented in source"* at best; **none is marked compiled or runtime-tested**. What was verified this pass: (1) the Java syntax of every file with `javac` (0 syntax errors; the only remaining javac errors are unresolved Minecraft symbols, which is expected without the game jars), and (2) the Minecraft targets of the four new mixins against the published **Yarn 1.21.11+build.4 javadoc** (see *Mixin targets*). Do the local build and the checklist before trusting anything.

## Versions
| Item | Value | How it was checked |
|---|---|---|
| Minecraft | 1.21.11 | `gradle.properties`, `fabric.mod.json` |
| Yarn | `1.21.11+build.6` | earlier pass read the upstream branch; this pass read the `1.21.11+build.4` javadoc for the classes listed under *Mixin targets* (the mapped names used there are identical in build 6 unless Yarn renamed them in between) |
| Fabric Loader | `0.18.4` | upstream tag exists; not resolved by Gradle |
| Fabric API | `0.141.3+1.21.11` | upstream tag exists; not resolved by Gradle |
| Fabric Loom | `1.15` | upstream tag exists; Loom 1.15 vs Gradle 9.2.0 compatibility **unverified** |
| Gradle | 9.2.0 | official wrapper files |
| JDK | 21 | required by Minecraft 1.21.x |

If Gradle rejects a combination, regenerate versions with <https://fabricmc.net/develop/template/>.

## Worlds: solo, your LAN world, remote servers
`WorldContext` classifies the world from the integrated server itself:
- **Solo**: integrated server, you are the only player online (a world opened to LAN with nobody joined counts as solo; no verified API tells the host client the difference).
- **LAN host**: integrated server and at least one other player online.
- **Remote**: connected to anyone else's server, including a friend's LAN world you joined as a guest. Nothing is ever relaxed here; every own-world module refuses to enable and is switched off if you join.

Rules (re-reviewed this pass):
- Modules that affect only you (movement, inventory, building, visuals, cosmetics) keep working while friends are in your LAN world.
- Combat modules that pick targets (AimAssist, TriggerBot, ShieldBreaker, AutoMace, Criticals, Hitbox) keep working in your LAN world but **never target players** there.
- Modules that could blow up, push or hit other players (AutoCrystal, AutoAnchor, AutoCart, KeyCart, KeepSprint, JumpReset, Velocity, KnockbackDisplace) switch off as soon as a guest joins.
- **Changed this pass:** `PlayerESP` is now alone-in-your-world only. In a LAN session it would have been a wall-hack on your friends, which is not a fair thing to leave on for the host.
- Nothing bypasses anti-cheat, server permissions or access controls and nothing exposes hidden information (Xray and StorageESP are not provided; Search, Nametags and PearlCatch use only what is already visible or your own projectiles).
- Known limits: reach/hitbox changes (SpearReach, Hitbox) are client-side only; an integrated server validates hits with its own values.

## Build (reproducible local process)
Requirements: JDK 21 and internet access to `maven.fabricmc.net`, `repo.maven.apache.org`, `libraries.minecraft.net`, `piston-meta.mojang.com`, `services.gradle.org`.
```
cd noctis-client
./gradlew build            # Windows: gradlew.bat build
./gradlew runClient        # dev client with the mod loaded
```
Output: `build/libs/noctis-client-1.0.0.jar` (not the `-sources` jar). Install: Fabric Loader for 1.21.11 + Fabric API + that jar in `.minecraft/mods/`.
If compilation fails, fix errors top-down and report them; the riskiest spots are under *Known risk points*. **No compiled JAR is included in this zip because the build could not be run.**

## Mixin targets (all new mixins live in `noctis-extra.mixins.json`: `required: false`, `defaultRequire: 0`, so a wrong target skips that mixin instead of crashing the game)
| Mixin | Target and signature | Evidence |
|---|---|---|
| `CapeFeatureRendererMixin` | `CapeFeatureRenderer.render(MatrixStack, OrderedRenderCommandQueue, int, PlayerEntityRenderState, float, float)` | Yarn 1.21.11 javadoc (class + method); `PlayerEntityRenderState.skinTextures/id`, `SkinTextures(body, cape, elytra, model, secure)` and `AssetInfo.TextureAssetInfo(Identifier, Identifier)` also read there |
| `EntityRendererMixin` | `EntityRenderer.updateRenderState(Entity, EntityRenderState, float)`, TAIL | `EntityRenderState.displayName` field read in the javadoc; method shape cross-checked against the compiled Echo jar for 1.21.11 |
| `KeyboardInputMixin` | `KeyboardInput.tick()`, TAIL; writes protected `Input.movementVector` (`Vec2f`) | Yarn 1.21.11 javadoc (`Input`, `KeyboardInput`) |
| `HeldItemRendererMixin` | `HeldItemRenderer.renderFirstPersonItem(AbstractClientPlayerEntity, float, float, Hand, float, ItemStack, float, MatrixStack, OrderedRenderCommandQueue, int)`, after the first `MatrixStack.push()` | `OrderedRenderCommandQueue` package read in the javadoc; the full parameter list and the `push()` injection point were read from the compiled Echo jar (built for 1.21.11), not from the Yarn page for this method |
Each hook counts its calls; ViewModel, Capes, Nametags and MoveFix show *"hook inactive"* in the ClickGUI if the mixin never fires, so a silent no-op is reported instead of hidden.
The Echo jar was used only as a reference for method shapes and naming; no Echo code or assets were copied and all Noctis modules are original implementations.

## Controls
- **Right Shift**: open the ClickGUI (rebindable on the ClickGUI module).
- Left-click a module row or its switch: toggle. Right-click the row or press `+`: settings, keybind, status.
- Search bar filters across categories. Mouse wheel scrolls. Drag the top strip to move the window, the bottom-right grip to resize.
- **HUD Editor** and **Profiles** live in the sidebar.
- The GUI was written without being run, so layout and visual polish are **unverified**.

## Profiles and config
Files: `config/noctis/profiles/NAME.json`. Every load is validated per value; bad values fall back to defaults, an unreadable file is renamed `NAME.corrupt-<time>`. Export writes `config/noctis/export.json`, import reads `config/noctis/import.json`. A profile may carry `"server": "address-fragment"` to load on join. No credentials are read or stored. Custom capes go in `config/noctis/capes/` (PNG, 64x32 or an exact 2:1 multiple).

## Module catalogue: all 82 entries
Status counts: **31 implemented (any world), 34 own-world-only, 2 unfinished, 15 deliberately unavailable = 82** (plus 3 DonutCommand macros and 9 HUD elements, not counted).
Columns: **In source** = real code exists (not a placeholder). **Compiled** = built by Gradle against Minecraft. **Runtime-tested** = seen working in a launched client. The last two are **no for every module** because no build or launch was possible.

| # | Module | Status | In source | Compiled | Runtime-tested | Where it runs / reason |
|---|---|---|---|---|---|---|
| 1 | AimVisualizer | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 2 | Ambience | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 3 | AutoTool | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 4 | AutoWalk | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 5 | ClickGUI | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 6 | ClientThemes | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 7 | CommandLogger | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 8 | ElytraSwap | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 9 | Export | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 10 | FastStairs | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 11 | Fullbright | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 12 | KeyCharge | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 13 | KeyPearlMacro | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 14 | LightESP | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 15 | MaceSwap | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 16 | PotRefill | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 17 | Search | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 18 | SelfDestruct | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 19 | Sprint | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 20 | SwingSpeed | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 21 | TargetESP | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 22 | Teams | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 23 | TotemDoubleHand | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 24 | TotemOffhand | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 25 | Trajectory | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 26 | Transactions | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) |
| 27 | AimAssist | Own world only | yes | no | no | solo + own LAN world; never targets players while guests are online |
| 28 | AutoAnchor | Own world only | yes | no | no | alone in your own world only (off once a LAN guest joins) |
| 29 | AutoCart | Own world only | yes | no | no | alone in your own world only (off once a LAN guest joins) |
| 30 | AutoCrystal | Own world only | yes | no | no | alone in your own world only (off once a LAN guest joins) |
| 31 | AutoMace | Own world only | yes | no | no | solo + own LAN world; never targets players while guests are online |
| 32 | AutoTotem | Own world only | yes | no | no | solo + own LAN world |
| 33 | ChestStealer | Own world only | yes | no | no | solo + own LAN world |
| 34 | Criticals | Own world only | yes | no | no | solo + own LAN world; never targets players while guests are online |
| 35 | FastEXP | Own world only | yes | no | no | solo + own LAN world |
| 36 | FastPlace | Own world only | yes | no | no | solo + own LAN world |
| 37 | Freecam | Own world only | yes | no | no | solo + own LAN world |
| 38 | GuiWalk | Own world only | yes | no | no | solo + own LAN world |
| 39 | Hitbox | Own world only | yes | no | no | solo + own LAN world; never targets players while guests are online |
| 40 | JumpReset | Own world only | yes | no | no | alone in your own world only (off once a LAN guest joins) |
| 41 | KeepSprint | Own world only | yes | no | no | alone in your own world only (off once a LAN guest joins) |
| 42 | KeyCart | Own world only | yes | no | no | alone in your own world only (off once a LAN guest joins) |
| 43 | NoBreakDelay | Own world only | yes | no | no | solo + own LAN world |
| 44 | NoJumpDelay | Own world only | yes | no | no | solo + own LAN world |
| 45 | NoRender | Own world only | yes | no | no | solo + own LAN world |
| 46 | NoWeb | Own world only | yes | no | no | solo + own LAN world; needs the EntityAccessor mixin (optional config, skipped safely if absent) |
| 47 | PlayerESP | Own world only | yes | no | no | alone in your own world only (off once a LAN guest joins) |
| 48 | Replenish | Own world only | yes | no | no | solo + own LAN world |
| 49 | ShieldBreaker | Own world only | yes | no | no | solo + own LAN world; never targets players while guests are online |
| 50 | SmartPot | Own world only | yes | no | no | solo + own LAN world |
| 51 | SnapTap | Own world only | yes | no | no | solo + own LAN world |
| 52 | SpearReach | Own world only | yes | no | no | solo + own LAN world |
| 53 | Speed | Own world only | yes | no | no | solo + own LAN world |
| 54 | Step | Own world only | yes | no | no | solo + own LAN world |
| 55 | TotemRefill | Own world only | yes | no | no | solo + own LAN world |
| 56 | TriggerBot | Own world only | yes | no | no | solo + own LAN world; never targets players while guests are online |
| 57 | Tunneler | Own world only | yes | no | no | solo + own LAN world |
| 58 | Velocity | Own world only | yes | no | no | alone in your own world only (off once a LAN guest joins) |
| 59 | AttributeMine | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) **[new this pass]** |
| 60 | Capes | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered); needs the CapeFeatureRenderer mixin (optional config, skipped safely if absent) **[new this pass]** |
| 61 | MoveFix | Own world only | yes | no | no | solo + own LAN world; needs the KeyboardInput mixin (optional config, skipped safely if absent) **[new this pass]** |
| 62 | Nametags | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered); needs the EntityRenderer mixin (optional config, skipped safely if absent) **[new this pass]** |
| 63 | PearlCatch | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered) **[new this pass]** |
| 64 | ViewModel | Implemented (any world) | yes | no | no | anywhere (client-side / visual / user-triggered); needs the HeldItemRenderer mixin (optional config, skipped safely if absent) **[new this pass]** |
| 65 | AntiTrap | Deliberately unavailable | no | no | no | Reviewed: automatic block placement against traps reacts to other players and has no specified behaviour; the only workable reading is PvP automation. Deliberately unavailable. |
| 66 | AutoLava | Deliberately unavailable | no | no | no | Reviewed: automated lava placement is a griefing / PvP trap tool and no single-player use case was identified. Deliberately unavailable. |
| 67 | Backtrack | Deliberately unavailable | no | no | no | Reviewed: hits entities at stale positions by exploiting network timing and server-side hit validation. No single-player or accessibility use exists (an integrated server has no latency to shape). Deliberately unavailable. |
| 68 | BlockBruteforcer | Deliberately unavailable | no | no | no | Reviewed: repeatedly probing blocks has no specified behaviour and no legitimate use was identified. Deliberately unavailable. |
| 69 | ComboHelper | Deliberately unavailable | no | no | no | Reviewed: combo-keeping assistance only has meaning against other players; it is unfair combat manipulation. Deliberately unavailable. |
| 70 | CrystalOptimizer | Deliberately unavailable | no | no | no | Reviewed: predicts/removes end crystals on the client to win crystal-PvP races, i.e. it alters hit registration against other players. No legitimate private-world use (mobs do not fight with crystals). Deliberately unavailable. |
| 71 | DiveBomb | Deliberately unavailable | no | no | no | Reviewed: an automated elytra-dive-and-mace attack is combat automation; the manual building blocks (ElytraSwap, MaceSwap, AutoMace in your own world) already exist. Deliberately unavailable. |
| 72 | KnockbackDelay | Deliberately unavailable | no | no | no | Reviewed: holds back velocity packets so knockback arrives late (lag-based combat manipulation). An integrated server has no packet latency to hold, so there is no private-world use. Deliberately unavailable. |
| 73 | KnockbackDisplace | Own world only | yes | no | no | alone in your own world only (off once a LAN guest joins) **[new this pass]** |
| 74 | NoLungeCooldown | Deliberately unavailable | no | no | no | Reviewed: the lunge cooldown is enforced by the server, so a client-side bypass either desyncs or is a combat advantage on a LAN/remote world. Deliberately unavailable. |
| 75 | NoSlow | Unfinished (planned) | no | no | no | Reviewed: acceptable as an own-world convenience, but the slowdown is applied inside ClientPlayerEntity movement code and its 1.21.11 Yarn hook could not be verified from this sandbox (only pre-1.17 and mapping-history pages were reachable). On remote servers it would bypass movement rules, so it would stay own-world only. Planned. |
| 76 | Piercing | Deliberately unavailable | no | no | no | Reviewed: spear/piercing automation that extends what a hit can reach; hit validation is server-side, so it is either useless or a combat advantage over other players. Deliberately unavailable (SpearReach covers the private-world case). |
| 77 | SpearAssist | Deliberately unavailable | no | no | no | Reviewed: aiming/charging assistance for the 1.21.11 spear is combat automation; the spear APIs were not checked against 1.21.11 here. Deliberately unavailable. |
| 78 | SpearLunge | Deliberately unavailable | no | no | no | Reviewed: automating lunge attacks is combat automation (a lunge is a normal use-item action the player can already trigger). Deliberately unavailable. |
| 79 | StorageESP | Deliberately unavailable | no | no | no | Reviewed: highlighting containers through walls is hidden-information ESP. Not provided. (Search already outlines blocks you can see.) |
| 80 | TimerExploit | Unfinished (planned) | no | no | no | Reviewed: a game-speed multiplier is acceptable alone in your own world, but the RenderTickCounter.Dynamic hook for 1.21.11 could not be verified here; client-side speed-up is a movement-rule bypass on any other server. Would be SOLO-only. Planned. |
| 81 | TotemHit | Deliberately unavailable | no | no | no | Reviewed: behaviour is undefined and every plausible reading is combat automation. The defensive half already exists as AutoTotem / TotemOffhand / TotemRefill. Deliberately unavailable. |
| 82 | Xray | Deliberately unavailable | no | no | no | Reviewed: terrain transparency exposes hidden ore and caves. Not provided, including in single-player worlds shared over LAN. |

## Review of the 18 formerly unavailable modules
| Module | Outcome | Why |
|---|---|---|
| KnockbackDisplace | **Implemented**, alone in your own world only | Rotates/scales the knockback you take; same mechanism as Velocity, no packets, conflicts with Velocity |
| NoSlow | Unfinished (planned) | Legitimate as an own-world convenience, but the 1.21.11 hook inside the client player's movement code could not be verified; would stay own-world only |
| TimerExploit | Unfinished (planned) | A game-speed multiplier is fine alone in your own world, but the `RenderTickCounter` hook could not be verified; would be solo-only |
| Backtrack, CrystalOptimizer, KnockbackDelay | Unavailable | Network-timing / hit-registration manipulation against other players; no single-player use |
| TotemHit, ComboHelper, DiveBomb, Piercing, SpearAssist, SpearLunge, NoLungeCooldown | Unavailable | Combat automation or server-enforced mechanics; defensive/manual equivalents already exist (AutoTotem, TotemOffhand, ElytraSwap, MaceSwap, SpearReach) |
| AntiTrap, AutoLava, BlockBruteforcer | Unavailable | Unspecified behaviour whose only workable readings are PvP traps/griefing; no private-world use identified |
| StorageESP, Xray | Unavailable | Hidden-information ESP / terrain transparency |

## Behaviour choices for the six new modules (all configurable in the ClickGUI)
- **ViewModel**: X/Y/Z offset, scale and three rotations for main, off or both hands; +X always means "away from the body", also for left-handed players. Maps and the spyglass use different render paths and are not specially handled.
- **Capes**: client-side only (nobody else sees it). Four bundled designs plus a custom PNG; optional matching elytra. 22x17 legacy cape files are not converted. Each distinct custom file keeps one small texture registered until you quit.
- **Nametags**: adds health, distance and ping to labels vanilla already draws. Label size/background are vanilla; scaling needs a label-render mixin that was not written.
- **MoveFix**: Noctis has no silent rotations, so it is a companion to AimAssist: it rotates your movement input by the opposite of AimAssist's turn to keep your direction of travel. Without AimAssist it does nothing. Own world only.
- **AttributeMine**: chooses the hotbar slot with the highest vanilla break progress for the targeted block (using the game's own calculation with each slot briefly selected), skipping tools below a durability threshold. Limit: bonuses that vanilla adds to the attribute map only after a slot change are not seen for not-yet-held items.
- **PearlCatch**: informational only: path and landing marker for your own thrown pearls plus a one-time warning for void, lava, fire or lethal landing. It does not steer, cancel or automate anything.

## Genuine remaining limitations
- **No build and no runtime test exist.** First task on your machine: `./gradlew build`, then the checklist below. Send me the compiler output and I will fix it.
- **Unfinished:** NoSlow, TimerExploit (hooks unverified). **Deliberately unavailable:** the 15 entries marked so above.
- Unverified runtime details: whether the debug filled-box layer used by `Render3D` draws correctly; that the `HeldItemRenderer` injection point produces a sensible transform; that dynamic cape textures bind through `AssetInfo.TextureAssetInfo`; Freecam's camera-entity approach.
- SpearReach / Hitbox / Velocity change client-side values only.
- SelfDestruct disables every module and autosave then stores that state in the active profile.

## Known risk points (most likely compile/runtime fixes)
1. Input API in `ClickGuiScreen` / `HudEditorScreen` (`Click`, `KeyInput`, `CharInput` records; accessor names were not individually checked).
2. `Render2D.push/pop` (`Matrix3x2fStack`).
3. `EntityAttributes.STEP_HEIGHT` / `ENTITY_INTERACTION_RANGE` constants, `RaycastContext` enums, `Items.*` constants.
4. `Render3D` vertex format and camera-relative matrices.
5. `Freecam`: `new ArmorStandEntity(world, x, y, z)`; fields `lastRenderX/Y/Z`, `lastYaw/lastPitch`.
6. New code not checked by a compiler: `BlockState.calcBlockBreakingDelta(PlayerEntity, BlockView, BlockPos)` (AttributeMine), `EnderPearlEntity` package `net.minecraft.entity.projectile.thrown`, `FluidTags.LAVA`, `PlayerListEntry.getLatency()`, `GameOptions.getPerspective().isFirstPerson()`, `NativeImageBackedTexture(Supplier<String>, NativeImage)` and `TextureManager.registerTexture(Identifier, AbstractTexture)` (the last two seen in Echo's bytecode, not in Yarn pages).
7. Gradle: Loom 1.15 vs Gradle 9.2.0 compatibility.

## Troubleshooting
- *Mod does not load*: Fabric API missing, wrong Minecraft version, or Java < 21.
- *A module won't enable*: open its row; the status line / toast gives the reason (guests online, remote server, unfinished, unavailable).
- *"Render hook inactive" under ViewModel/Capes/Nametags/MoveFix*: the mixin did not apply; check `latest.log` for the Mixin warning and report it.
- *Config reset unexpectedly*: look for `NAME.corrupt-*` beside the profile.

## Testing checklist (nothing verified yet; tick after doing it)
- [ ] `./gradlew build` succeeds; `./gradlew runClient` reaches the title screen
- [ ] No Mixin warnings for `noctis-extra.mixins.json` in `latest.log`
- [ ] ClickGUI opens (Right Shift); search, scroll, drag/resize, all setting widgets, themes
- [ ] HUD editor and all 9 HUD elements; positions persist after restart
- [ ] Profiles: create, load, delete, export, import, reset; corrupt profile recovery
- [ ] **New:** ViewModel (each hand, left-handed main arm, scale/rotation), Capes (4 presets, custom PNG, elytra match, F5 view), Nametags (second player via LAN), MoveFix with AimAssist, AttributeMine (pickaxe vs shovel vs hand), PearlCatch (throw over void/lava/land)
- [ ] KnockbackDisplace in a solo world; it turns itself off when a friend joins
- [ ] Implemented modules, one by one (enable, use, disable restores state)
- [ ] World render: Trajectory (bow, pearl), LightESP, Search (nothing behind walls), AimVisualizer
- [ ] Freecam: camera moves, body stays, disabling restores the view
- [ ] Own-world modules solo; then open to LAN and join with a friend: self-only modules stay on, solo-only modules (incl. PlayerESP) switch off, combat modules ignore your friend
- [ ] On a remote server: all own-world modules refuse to enable
- [ ] DonutCommand macros: refuse empty command, wrong server, credential-style commands, repeat within 1 s
- [ ] Idle performance with GUI closed and modules off
