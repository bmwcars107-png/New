package io.noctis.module.impl;

import io.noctis.Teams;
import io.noctis.module.*;
import io.noctis.module.Module;
import io.noctis.setting.BoolSetting;
import io.noctis.setting.NumSetting;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import io.noctis.setting.ModeSetting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import static io.noctis.module.impl.Modules.unavailable;

/**
 * Combat. Everything that changes combat outcomes is PRIVATE_TEST (refuses to run on multiplayer servers).
 * Anything that would automate crystal/anchor/cart/mace combat, alter hit registration or knockback is
 * deliberately not provided and listed as such.
 */
public final class CombatModules {
    private CombatModules() {}

    static void register() {
        ModuleManager.register(new AimAssist());
        ModuleManager.register(new TriggerBot());
        ModuleManager.register(new MaceSwap());
        ModuleManager.register(new ShieldBreaker());
        ModuleManager.register(new AutoCrystal());
        ModuleManager.register(new AutoAnchor());
        ModuleManager.register(new AutoCart());
        ModuleManager.register(new KeyCart());
        ModuleManager.register(new AutoMace());
        ModuleManager.register(new Criticals());
        ModuleManager.register(new Hitbox());
        ModuleManager.register(new SpearReach());

        Category c = Category.COMBAT;
        Status B = Status.BLOCKED;
        unavailable(c, B, "Backtrack", "Hits an entity at a past position.", "Reviewed: hits entities at stale positions by exploiting network timing and server-side hit validation. No single-player or accessibility use exists (an integrated server has no latency to shape). Deliberately unavailable.");
        unavailable(c, B, "CrystalOptimizer", "Speeds up crystal removal.", "Reviewed: predicts/removes end crystals on the client to win crystal-PvP races, i.e. it alters hit registration against other players. No legitimate private-world use (mobs do not fight with crystals). Deliberately unavailable.");
        unavailable(c, B, "KnockbackDelay", "Delays incoming knockback.", "Reviewed: holds back velocity packets so knockback arrives late (lag-based combat manipulation). An integrated server has no packet latency to hold, so there is no private-world use. Deliberately unavailable.");
        unavailable(c, B, "Piercing", "Piercing-weapon automation.", "Reviewed: spear/piercing automation that extends what a hit can reach; hit validation is server-side, so it is either useless or a combat advantage over other players. Deliberately unavailable (SpearReach covers the private-world case).");
        unavailable(c, B, "SpearAssist", "Spear aiming/charge automation.", "Reviewed: aiming/charging assistance for the 1.21.11 spear is combat automation; the spear APIs were not checked against 1.21.11 here. Deliberately unavailable.");
        unavailable(c, B, "SpearLunge", "Automated spear lunge attacks.", "Reviewed: automating lunge attacks is combat automation (a lunge is a normal use-item action the player can already trigger). Deliberately unavailable.");
        unavailable(c, B, "TotemHit", "Automated totem-aware hitting.", "Reviewed: behaviour is undefined and every plausible reading is combat automation. The defensive half already exists as AutoTotem / TotemOffhand / TotemRefill. Deliberately unavailable.");
    }

    static float[] angles(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        return new float[]{yaw, pitch};
    }

    // ------------------------------------------------------------------------------------------
    public static final class AimAssist extends Module {
        private final NumSetting range = add(new NumSetting("Range", "Maximum target distance (blocks)", 4.5, 2, 6, 0.1));
        private final NumSetting fov = add(new NumSetting("FOV", "Only targets within this angle of your crosshair", 60, 10, 180, 1));
        private final NumSetting speed = add(new NumSetting("Speed", "Maximum degrees turned per tick", 4, 0.5, 20, 0.5));
        private final BoolSetting players = add(new BoolSetting("Players only", "Ignore mobs", false));
        private final BoolSetting needLos = add(new BoolSetting("Line of sight", "Require a visible target", true));
        /** Last aim target, read by AimVisualizer. */
        public static volatile Vec3d aimPoint;
        public static volatile long aimMillis;

        public AimAssist() {
            super("AimAssist", "Smoothly nudges your aim toward the nearest target. Singleplayer test worlds only.", Category.COMBAT, Status.PRIVATE_TEST);
        }

        @Override protected void onTick() {
            var p = player();
            if (mc.currentScreen != null || p == null) return;
            Vec3d eye = p.getEyePos();
            float[] best = null;
            Vec3d bestPoint = null;
            double bestAngle = fov.val();
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || e.isSpectator() || !mayTarget(e)) continue;
                if (players.on() && !(e instanceof PlayerEntity)) continue;
                if (e instanceof PlayerEntity pe && Teams.isFriend(pe.getName().getString())) continue;
                if (p.distanceTo(e) > range.val()) continue;
                if (needLos.on() && !p.canSee(e)) continue;
                float[] r = angles(eye, e.getBoundingBox().getCenter());
                double ang = Math.hypot(MathHelper.wrapDegrees(r[0] - p.getYaw()), r[1] - p.getPitch());
                if (ang < bestAngle) { bestAngle = ang; best = r; bestPoint = e.getBoundingBox().getCenter(); }
            }
            if (best == null) return;
            aimPoint = bestPoint; aimMillis = System.currentTimeMillis();
            float s = speed.floatVal();
            float dYaw = MathHelper.clamp(MathHelper.wrapDegrees(best[0] - p.getYaw()), -s, s);
            p.setYaw(p.getYaw() + dYaw);
            ExtraModules.MoveFix.note(dYaw);
            p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(best[1] - p.getPitch(), -s, s), -90f, 90f));
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class TriggerBot extends Module {
        private final NumSetting charge = add(new NumSetting("Min charge", "Attack-cooldown progress required", 1.0, 0.3, 1.0, 0.05));
        private final BoolSetting players = add(new BoolSetting("Players only", "Ignore mobs", false));

        public TriggerBot() {
            super("TriggerBot", "Attacks when your crosshair is on a living target and your weapon is charged. Singleplayer test worlds only.", Category.COMBAT, Status.PRIVATE_TEST);
        }

        @Override protected void onTick() {
            var p = player();
            if (mc.currentScreen != null || p == null || !(mc.targetedEntity instanceof LivingEntity le) || !le.isAlive()) return;
            if (!mayTarget(le)) return;
            if (players.on() && !(le instanceof PlayerEntity)) return;
            if (le instanceof PlayerEntity pe && Teams.isFriend(pe.getName().getString())) return;
            if (p.getAttackCooldownProgress(0.5f) < charge.floatVal()) return;
            mc.interactionManager.attackEntity(p, le);
            p.swingHand(Hand.MAIN_HAND);
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class MaceSwap extends ActionModule {
        public MaceSwap() {
            super("MaceSwap", "Selects the first mace in your hotbar when triggered (bind a key). User-triggered shortcut; no attack is performed.", Category.COMBAT, Status.IMPLEMENTED);
        }
        @Override protected void run() {
            if (!inGame()) return;
            int s = Inv.hotbar(st -> st.isOf(Items.MACE));
            if (s < 0) Inv.say("MaceSwap: no mace in your hotbar."); else Inv.select(s);
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class ShieldBreaker extends Module {
        private int previous = -1;
        public ShieldBreaker() {
            super("ShieldBreaker", "Switches to an axe while the targeted player is blocking, then switches back. Does not attack. Singleplayer test worlds only.", Category.COMBAT, Status.PRIVATE_TEST);
        }
        @Override protected void onTick() {
            boolean blocking = mc.targetedEntity instanceof LivingEntity le && mayTarget(le) && le.isBlocking();
            if (blocking && previous < 0) {
                int axe = Inv.hotbar(st -> st.isIn(ItemTags.AXES));
                if (axe >= 0 && axe != Inv.selected()) { previous = Inv.selected(); Inv.select(axe); }
            } else if (!blocking && previous >= 0) {
                Inv.select(previous);
                previous = -1;
            }
        }
        @Override protected void onDisable() { if (previous >= 0) Inv.select(previous); previous = -1; }
    }

    // ------------------------------------------------------------------------------------------
    private static void attack(Module m, Entity e) {
        var mc = net.minecraft.client.MinecraftClient.getInstance();
        mc.interactionManager.attackEntity(mc.player, e);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    /** Use the item in the given hotbar slot on the block under the crosshair, then restore the previous slot. */
    private static boolean useOnLookedBlock(int slot, BlockHitResult hit) {
        var mc = net.minecraft.client.MinecraftClient.getInstance();
        int prev = Inv.selected();
        Inv.select(slot);
        var r = mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        mc.player.swingHand(Hand.MAIN_HAND);
        Inv.select(prev);
        return r.isAccepted();
    }

    private static BlockHitResult lookedBlock(net.minecraft.client.MinecraftClient mc) {
        return mc.crosshairTarget instanceof BlockHitResult h && h.getType() == HitResult.Type.BLOCK ? h : null;
    }

    /** Breaks nearby end crystals and places crystals on the obsidian/bedrock top face you are looking at. */
    public static final class AutoCrystal extends Module {
        private final NumSetting range = add(new NumSetting("Break range", "Maximum crystal distance (blocks)", 4.5, 2, 6, 0.1));
        private final NumSetting delay = add(new NumSetting("Delay", "Ticks between actions", 2, 0, 10, 1));
        private final BoolSetting place = add(new BoolSetting("Place", "Place crystals on the obsidian/bedrock you look at", true));
        private int wait;
        public AutoCrystal() { super("AutoCrystal", "Breaks nearby end crystals and places crystals where you look. Singleplayer test worlds only.", Category.COMBAT, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            if (wait-- > 0 || mc.currentScreen != null) return;
            for (Entity e : mc.world.getEntities()) {
                if (e instanceof EndCrystalEntity && player().distanceTo(e) <= range.val()) { attack(this, e); wait = delay.intVal(); return; }
            }
            if (!place.on()) return;
            BlockHitResult hit = lookedBlock(mc);
            if (hit == null || hit.getSide() != net.minecraft.util.math.Direction.UP) return;
            var st = mc.world.getBlockState(hit.getBlockPos());
            if (!st.isOf(Blocks.OBSIDIAN) && !st.isOf(Blocks.BEDROCK)) return;
            int slot = Inv.hotbar(s -> s.isOf(Items.END_CRYSTAL));
            if (slot < 0) return;
            useOnLookedBlock(slot, hit);
            wait = delay.intVal();
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class AutoAnchor extends Module {
        private final NumSetting charges = add(new NumSetting("Charges", "Charge the anchor you look at up to this level", 1, 1, 4, 1));
        private final BoolSetting detonate = add(new BoolSetting("Detonate", "Also detonate it (explodes outside the Nether - stay away)", false));
        private final NumSetting delay = add(new NumSetting("Delay", "Ticks between actions", 4, 1, 20, 1));
        private int wait;
        public AutoAnchor() { super("AutoAnchor", "Charges (and optionally detonates) the respawn anchor you look at, using glowstone from your hotbar. Singleplayer test worlds only.", Category.COMBAT, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            if (wait-- > 0 || mc.currentScreen != null) return;
            BlockHitResult hit = lookedBlock(mc);
            if (hit == null) return;
            var st = mc.world.getBlockState(hit.getBlockPos());
            if (!st.isOf(Blocks.RESPAWN_ANCHOR)) return;
            int have = st.get(RespawnAnchorBlock.CHARGES);
            if (have < charges.intVal()) {
                int glow = Inv.hotbar(s -> s.isOf(Items.GLOWSTONE));
                if (glow >= 0) { useOnLookedBlock(glow, hit); wait = delay.intVal(); }
            } else if (detonate.on()) {
                int other = Inv.hotbar(s -> !s.isOf(Items.GLOWSTONE));
                if (other >= 0) { useOnLookedBlock(other, hit); wait = delay.intVal(); }
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    /** One step of the TNT-minecart routine: ignite a nearby cart, otherwise place one on the rail you look at. */
    private static boolean cartStep(double range) {
        var mc = net.minecraft.client.MinecraftClient.getInstance();
        var p = mc.player;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof TntMinecartEntity t && !t.isPrimed() && p.distanceTo(e) <= range) {
                int lighter = Inv.hotbar(s -> s.isOf(Items.FLINT_AND_STEEL) || s.isOf(Items.FIRE_CHARGE));
                if (lighter < 0) return false;
                int prev = Inv.selected();
                Inv.select(lighter);
                mc.interactionManager.interactEntity(p, e, Hand.MAIN_HAND);
                Inv.select(prev);
                return true;
            }
        }
        BlockHitResult hit = lookedBlock(mc);
        if (hit == null || !mc.world.getBlockState(hit.getBlockPos()).isIn(BlockTags.RAILS)) return false;
        int cart = Inv.hotbar(s -> s.isOf(Items.TNT_MINECART));
        return cart >= 0 && useOnLookedBlock(cart, hit);
    }

    public static final class AutoCart extends Module {
        private final NumSetting delay = add(new NumSetting("Delay", "Ticks between actions", 6, 2, 40, 1));
        private final NumSetting range = add(new NumSetting("Range", "Maximum cart distance (blocks)", 4, 2, 6, 0.5));
        private int wait;
        public AutoCart() { super("AutoCart", "Places a TNT minecart on the rail you look at and ignites it (flint and steel / fire charge in hotbar). Singleplayer test worlds only.", Category.COMBAT, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            if (wait-- > 0 || mc.currentScreen != null) return;
            if (cartStep(range.val())) wait = delay.intVal();
        }
    }

    public static final class KeyCart extends ActionModule {
        public KeyCart() { super("KeyCart", "Does one TNT-minecart step (place on the rail you look at, or ignite a nearby cart) when triggered. Singleplayer test worlds only.", Category.COMBAT, Status.PRIVATE_TEST); }
        @Override protected void run() {
            if (!inGame() || mc.currentScreen != null) return;
            if (!cartStep(4.5)) Inv.say("KeyCart: need a TNT minecart + lighter in your hotbar and a rail under your crosshair (or a nearby cart).");
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class AutoMace extends Module {
        private final NumSetting fall = add(new NumSetting("Min fall", "Minimum fall distance before striking (blocks)", 1.5, 0.5, 20, 0.5));
        private final BoolSetting back = add(new BoolSetting("Switch back", "Return to your previous slot", true));
        private int previous = -1;
        public AutoMace() { super("AutoMace", "While falling, swaps to a hotbar mace and attacks the living entity under your crosshair. Singleplayer test worlds only.", Category.COMBAT, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            var p = player();
            boolean falling = !p.isOnGround() && p.fallDistance >= fall.val();
            if (falling && mc.targetedEntity instanceof LivingEntity le && mayTarget(le) && le.isAlive() && p.distanceTo(le) <= 4.5) {
                int mace = Inv.hotbar(s -> s.isOf(Items.MACE));
                if (mace < 0) return;
                if (previous < 0 && mace != Inv.selected()) previous = Inv.selected();
                Inv.select(mace);
                attack(this, le);
            } else if (previous >= 0 && p.isOnGround()) {
                if (back.on()) Inv.select(previous);
                previous = -1;
            }
        }
        @Override protected void onDisable() { if (previous >= 0 && back.on()) Inv.select(previous); previous = -1; }
    }

    // ------------------------------------------------------------------------------------------
    public static final class Criticals extends Module {
        public Criticals() { super("Criticals", "Jump-crit assist: when you attack while standing on the ground, you jump so the hit lands while falling. Singleplayer test worlds only.", Category.COMBAT, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            var p = player();
            if (mc.currentScreen == null && mc.options.attackKey.isPressed() && mc.targetedEntity instanceof LivingEntity tle && mayTarget(tle)
                    && p.isOnGround() && !p.isClimbing() && !p.isTouchingWater() && !p.hasVehicle()) p.jump();
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class Hitbox extends Module {
        private final NumSetting size = add(new NumSetting("Expand", "Extra hitbox size on every side (blocks)", 0.2, 0.0, 1.0, 0.05));
        private final BoolSetting players = add(new BoolSetting("Players only", "Ignore mobs", false));
        public Hitbox() { super("Hitbox", "Enlarges other living entities' client-side hitboxes so they are easier to target. Singleplayer test worlds only.", Category.COMBAT, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof LivingEntity) || e == mc.player || !mayTarget(e)) continue;
                if (players.on() && !(e instanceof PlayerEntity)) continue;
                e.setBoundingBox(e.getDimensions(e.getPose()).getBoxAt(e.getEntityPos()).expand(size.val()));
            }
        }
        @Override protected void onDisable() {
            if (mc.world == null) return;
            for (Entity e : mc.world.getEntities())
                if (e instanceof LivingEntity && e != mc.player) e.setBoundingBox(e.getDimensions(e.getPose()).getBoxAt(e.getEntityPos()));
        }
    }

    // ------------------------------------------------------------------------------------------
    /** Raises the entity interaction range while a spear is held. Spears are detected by item id ("..._spear"). */
    public static final class SpearReach extends Module {
        private final NumSetting reach = add(new NumSetting("Reach", "Entity interaction range while holding a spear (vanilla 3.0)", 4.5, 3.0, 6.0, 0.1));
        public SpearReach() { super("SpearReach", "Extends your attack reach while a spear is in your main hand. Singleplayer test worlds only. (Does not change the spear's own lunge or charge attributes.)", Category.COMBAT, Status.PRIVATE_TEST); }
        private boolean holdingSpear() { return Registries.ITEM.getId(player().getMainHandStack().getItem()).getPath().endsWith("_spear"); }
        @Override protected void onTick() {
            var a = player().getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
            if (a == null) return;
            double want = holdingSpear() ? reach.val() : 3.0;
            if (a.getBaseValue() != want) a.setBaseValue(want);
        }
        @Override protected void onDisable() {
            if (mc.player == null) return;
            var a = mc.player.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
            if (a != null) a.setBaseValue(3.0);
        }
    }
}
