package net.minecraft.client.render;

/**
 * Accesses the package-private debug filled-box layer exposed by Minecraft 1.21.11.
 * Kept as a small compatibility bridge for Noctis world rendering.
 */
public final class NoctisRenderLayerAccessor {
    private NoctisRenderLayerAccessor() {}

    public static RenderLayer debugFilledBox() {
        return RenderLayers.debugFilledBox();
    }
}
